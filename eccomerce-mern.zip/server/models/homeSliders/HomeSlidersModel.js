const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const homeSlidersSchema = new Schema({

    name:{type:String, required:true},
    description:{type:String, required:true},
    slider_imgs: {
        type: [String], // Array of strings for card images
        required:true
    },

},{
    timestamps:true,
});

const HomeSlidersModel = mongoose.model("Home-Sliders", homeSlidersSchema);

module.exports = HomeSlidersModel;