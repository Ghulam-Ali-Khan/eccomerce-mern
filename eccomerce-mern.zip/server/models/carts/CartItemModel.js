const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const cartItemsSchema = new Schema({
    product_id: { type: Schema.Types.ObjectId, ref: 'Products', required: true },
    quantity:{type:Number, required:true},
    cart_id:{ type: Schema.Types.ObjectId, ref: 'Carts', required: true },
},{
    timestamps:true,
});

const CartItemsModel = mongoose.model("CartItems", cartItemsSchema);

module.exports = CartItemsModel;