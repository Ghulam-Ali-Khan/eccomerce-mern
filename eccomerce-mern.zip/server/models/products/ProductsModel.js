const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const productsSchema = new Schema({

    name:{type:String, required:true},
    description:{type:String, required:true},
    category: { type: Schema.Types.ObjectId, ref: 'Categories', required: true },
    selling_price:{type:Number, required:true},
    retail_price :{type:Number, required:true},
    discount: {type:Number, required:true},
    quantity:{type:Number, required:true},
    card_imgs: {
        type: [String], // Array of strings for card images
        required:true
    },
    banner_imgs: {
        type: [String], // Array of strings for banner images
        required:true
    },
    meta_title : {type:String, required:true},
    meta_description: {type:String, required:true},
    meta_keywords: {type:String, required:true}

},{
    timestamps:true,
});

const ProductsModel = mongoose.model("Products", productsSchema);

module.exports = ProductsModel;