const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const categoriesSchema = new Schema({

    name:{type:String, required:true},
    description:{type:String, required:true},
    type: { 
        type: String, 
        required: true, 
        enum: ['product', 'blog'] // Only allow "product" or "blog"
    },
    card_imgs: {
        type: [String], // Array of strings for card images
        required:true
    },
    banner_imgs: {
        type: [String], // Array of strings for banner images
        required:true
    },
    meta_title : {type:String, required:true},
    meta_description: {type:String, required:true},
    meta_keywords: {type:String, required:true}

},{
    timestamps:true,
});

const CategoriesModel = mongoose.model("Categories", categoriesSchema);

module.exports = CategoriesModel;