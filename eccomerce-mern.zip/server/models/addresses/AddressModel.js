const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const addressItemsSchema = new Schema({
    user_id: { type: Schema.Types.ObjectId, ref: 'Users', required: true },
    order_id: {type: Schema.Types.ObjectId, ref: 'Orders', required: true}, 
    postal_code: { type: String,required: true },
    country:{type:String, required:true},
    city:{ type: String, required: true },
    address:{ type: String, required: true },
},{
    timestamps:true,
});

const addressItemsModel = mongoose.model("AddressItems", addressItemsSchema);

module.exports = addressItemsModel;