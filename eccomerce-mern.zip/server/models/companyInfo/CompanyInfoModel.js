const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const socialLinkSchema = new Schema({
    title: { type: String, required: true },
    link: { type: String, required: true },
    icon: { type: String, required: true }
});

const companyInfoSchema = new Schema({

    name:{type:String, required:true},
    description:{type:String, required:true},
    logo:[{ type: String, required: true }],
    email:{ type: String, required: true },
    social_links: {
        type: [socialLinkSchema], // Array of strings for card images
        required:true
    },
    meta_title : {type:String, required:true},
    meta_description: {type:String, required:true},
    meta_keywords: {type:String, required:true}

},{
    timestamps:true,
});

const CompanyInfoModel = mongoose.model("companyInfo", companyInfoSchema);

module.exports = CompanyInfoModel;