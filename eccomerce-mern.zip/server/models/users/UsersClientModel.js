const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const usersSchema = new Schema({
    phone:{ type: String, required: true },
    email : {type:String, required:true, unique: true },
    password: {type:String, required:true},
    token: {type:String, required:false}
},{
    timestamps:true,
});

const UsersModel = mongoose.model("UserClients", usersSchema);

module.exports = UsersModel;