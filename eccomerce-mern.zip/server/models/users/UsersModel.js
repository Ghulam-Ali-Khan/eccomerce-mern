const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const usersSchema = new Schema({

    first_name:{type:String, required:true},
    last_name:{type:String, required:true},
    phone:{ type: String, required: true },
    profile_picture: {
        type: [String], // Array of strings for card images
        required:true
    },
    email : {type:String, required:true, unique: true },
    username: {type:String, required:true, unique: true },
    password: {type:String, required:true},
    token: {type:String, required:false}
},{
    timestamps:true,
});

const UsersModel = mongoose.model("Users", usersSchema);

module.exports = UsersModel;