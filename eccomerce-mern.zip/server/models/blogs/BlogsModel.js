const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const blogsSchema = new Schema({

    name:{type:String, required:true},
    description:{type:String, required:true},
    category: { type: Schema.Types.ObjectId, ref: 'Categories', required: true },
    card_imgs: {
        type: [String], // Array of strings for card images
        required:true
    },
    banner_imgs: {
        type: [String], // Array of strings for banner images
        required:true
    },
    meta_title : {type:String, required:true},
    meta_description: {type:String, required:true},
    meta_keywords: {type:String, required:true}

},{
    timestamps:true,
});

const BlogsModel = mongoose.model("Blogs", blogsSchema);

module.exports = BlogsModel;