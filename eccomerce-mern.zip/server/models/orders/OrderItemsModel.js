const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const orderItemsSchema = new Schema({
    product_id: { type: Schema.Types.ObjectId, ref: 'Products', required: true },
    quantity:{type:Number, required:true},
    order_id:{ type: Schema.Types.ObjectId, ref: 'Orders', required: true },
},{
    timestamps:true,
});

const OrderItemsModel = mongoose.model("OrderItems", orderItemsSchema);

module.exports = OrderItemsModel;