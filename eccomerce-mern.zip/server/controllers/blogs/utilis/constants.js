const BLOG_FETCHED = 'blog retireved';
const BLOGS_FETCHED = 'blogs retireved';
const BLOG_UPDATED = 'blogs updation';
const BLOG_DELETE = 'blogs deleted';
const BLOG_CREATED = 'blogs retireved';


module.exports = {BLOG_FETCHED, BLOGS_FETCHED, BLOG_UPDATED, BLOG_DELETE, BLOG_CREATED};