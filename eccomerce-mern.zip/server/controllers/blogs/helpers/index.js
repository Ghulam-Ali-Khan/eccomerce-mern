function formateBlogData(req) {
    const { card_imgs, banner_imgs } = req.files;

    // converting images array to their names string array
    const cardImageFilenames = card_imgs ? card_imgs.map((image) => image.filename) : [];
    const bannerImageFilenames = banner_imgs ? banner_imgs.map((image) => image.filename) : [];

    const {
        name,
        description,
        category,
        meta_title,
        meta_description,
        meta_keywords,
    } = req.body;

    const finalObj = {
        card_imgs: cardImageFilenames,
        banner_imgs: bannerImageFilenames,
        category,
        name,
        description,
        meta_title,
        meta_description,
        meta_keywords,
    };

    if (!req?.files?.card_imgs) {
        delete finalObj.card_imgs; // Exclude cardImages from updatedData
    }
    if (!req?.files?.banner_imgs) {
        delete finalObj.banner_imgs; // Exclude bannerImages from updatedData
    }

    return finalObj;
}

module.exports = { formateBlogData };
