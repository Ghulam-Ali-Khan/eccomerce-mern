const CATEGORY_FETCHED = 'category retireved';
const CATEGORIES_FETCHED = 'categories retireved';
const CATEGORY_UPDATED = 'category updation';
const CATEGORY_DELETE = 'category deleted';
const CATEGORY_CREATED = 'category retireved';


module.exports = {CATEGORY_FETCHED, CATEGORIES_FETCHED, CATEGORY_UPDATED, CATEGORY_DELETE, CATEGORY_CREATED};