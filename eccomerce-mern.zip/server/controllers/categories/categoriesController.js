const {CATEGORY_FETCHED, CATEGORIES_FETCHED, CATEGORY_UPDATED, CATEGORY_DELETE, CATEGORY_CREATED} = require('./utilis/constants');
const CategoriesModel = require("@/models/categories/CategoriesModel");
const throwResponse = require("@/utilis/throwResponse");
const {formateCategoryData} = require("./helpers");


const categoriessController = {
  async createCategory(req, res, next) {
    try {
      // get already managed data obj for multiple uses
      const creationData = formateCategoryData(req);

      const newCategory= new CategoriesModel(creationData);

      // creation
      const createQuery = await newCategory.save();

      // helpers func to show response
      throwResponse(res, createQuery, CATEGORY_CREATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async updateCategory(req, res, next) {
    try {
      // get already managed data obj for multiple uses
      const updationData = formateCategoryData(req);

      const updatedQuery = await CategoriesModel.findByIdAndUpdate(
        req?.params?.id,
        updationData,
        { new: true }
      );

      // helpers func to show response
      throwResponse(res, updatedQuery, CATEGORY_UPDATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async deleteCategory(req, res, next) {
    try {
      const categoryIdsToDelete = req.body.categories_ids; // Assuming you get the array of product IDs from the request body

      const deletedCategories = await CategoriesModel.deleteMany({
        _id: { $in: categoryIdsToDelete },
      });

      // helpers func to show response
      throwResponse(res, deletedCategories.deletedCount > 0, CATEGORY_DELETE);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getAllCategories(req, res, next) {
    try {

      const {limit = process.env.DEFAULT_ITEMS_LIMIT , offset = process.env.DEFAULT_ITEMS_OFFSET, query="" } = req.query;

      const fetchedCategories = await CategoriesModel.find({
        $or: [
          { name: { $regex: query, $options: "i" } }, // Case-insensitive search on name
          { description: { $regex: query, $options: "i" } }, // Case-insensitive search on description
        ],
      }).skip(offset*limit).limit(limit);

      const totalCount = await CategoriesModel.countDocuments({
        $or: [
          { name: { $regex: query, $options: "i" } }, // Case-insensitive search on name
          { description: { $regex: query, $options: "i" } }, // Case-insensitive search on description
        ],
      });


      // helpers func to show response
      throwResponse(
        res,
        fetchedCategories,
        CATEGORIES_FETCHED,
        fetchedCategories,
        totalCount
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getCategoryWithId(req, res, next) {
    try {

        const categoryId = req.params.id;

      const fetchedCategory = await CategoriesModel.find({_id:categoryId});

      // helpers func to show response
      throwResponse(
        res,
        fetchedCategory,
        CATEGORY_FETCHED,
        fetchedCategory
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getCategoriesWithSearch(req, res, next) {
    try {
      const searchQuery = req.params.searched_string; // Assuming this is how you're getting the search query from the request body

      let fetchedCategories = null;

      if (searchQuery?.length > 0) {
        fetchedCategories = await CategoriesModel.find({
          $or: [
            { name: { $regex: searchQuery, $options: "i" } }, // Case-insensitive search on name
            { description: { $regex: searchQuery, $options: "i" } }, // Case-insensitive search on description
            { type: { $regex: searchQuery, $options: "i" } }, 
          ],
        });
      }

      // helpers func to show response
      throwResponse(
        res,
        fetchedCategories,
        CATEGORIES_FETCHED,
        fetchedCategories
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getCategoriesWithType(req, res, next) {
    try {
      const searchQuery = req.params.searched_string; // Assuming this is how you're getting the search query from the request body

      let fetchedCategories = null;

      if (searchQuery?.length > 0) {
        fetchedCategories = await CategoriesModel.find({
          $or: [
            { type: { $regex: searchQuery, $options: "i" } }, 
          ],
        });
      }

      // helpers func to show response
      throwResponse(
        res,
        fetchedCategories,
        CATEGORIES_FETCHED,
        fetchedCategories
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
};

module.exports = categoriessController;
