const {
  USERS_FETCHED,
  USER_CREATED,
  USER_LOGIN_SUCCESS,
} = require("./utilis/constants");
const ProductsModel = require("@/models/products/ProductsModel");
const UsersModel = require("@/models/users/UsersModel");
const throwResponse = require("@/utilis/throwResponse");
const { formateUserData } = require("./helpers");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const usersController = {
  async createUser(req, res, next) {
    try {
      // get already managed data obj for multiple uses
      const creationData = await formateUserData(req);

      const newUser = new UsersModel(creationData);

      // creation
      const createQuery = await newUser.save();

      // helpers func to show response
      throwResponse(res, createQuery, USER_CREATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async userLogin(req, res, next) {
    try {
      const { username, password } = req.body;

      const userGetQuery = await UsersModel.findOne({ username });

      if (!userGetQuery) {
        return res.status(404).json({ success: false, msg: "user not found" });
      }

      const { password: hashedPassword } = userGetQuery;

      const passwordMatch = await bcrypt.compare(password, hashedPassword);

      if (!passwordMatch) {
        return res
          .status(404)
          .json({ success: false, msg: "password did not matched" });
      }

      const token = jwt.sign(
        { id: userGetQuery._id, username },
        process.env.SECRET_KEY,
        { expiresIn: "6h" }
      );

      
      await UsersModel.findByIdAndUpdate(
        userGetQuery._id,
        {
          token,
        },
        { new: true }
      );

      return res
        .status(200)
        .json({
          success: true,
          msg: USER_LOGIN_SUCCESS,
          token,
          data: userGetQuery,
        });
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getAllUsers(req, res, next) {
    try {

      const {limit = process.env.DEFAULT_ITEMS_LIMIT , offset = process.env.DEFAULT_ITEMS_OFFSET, query="" } = req.query;

      const fetchedUsers = await UsersModel.find({
        $or: [
          { username: { $regex: query, $options: "i" } }, // Case-insensitive search on name
          { email: { $regex: query, $options: "i" } },
        ],
      }).skip(offset*limit).limit(limit);

      const totalCount = await UsersModel.countDocuments({
        $or: [
          { username: { $regex: query, $options: "i" } }, // Case-insensitive search on nam
          { email: { $regex: query, $options: "i" } },
        ],
      });

      // helpers func to show response
      throwResponse(
        res,
        fetchedUsers,
        USERS_FETCHED,
        fetchedUsers,
        totalCount
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
};

module.exports = usersController;
