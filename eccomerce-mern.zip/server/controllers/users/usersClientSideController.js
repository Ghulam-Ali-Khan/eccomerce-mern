const {
    USERS_FETCHED,
    USER_CREATED,
    USER_LOGIN_SUCCESS,
  } = require("./utilis/constants");
  const UsersModel = require("@/models/users/UsersClientModel");
  const throwResponse = require("@/utilis/throwResponse");
  const { formateUserClientData } = require("./helpers");
  const bcrypt = require("bcrypt");
  const jwt = require("jsonwebtoken");
  
  const usersController = {
    async createUser(req, res, next) {
      try {
        // get already managed data obj for multiple uses
        const creationData = await formateUserClientData(req);
  
        const newUser = new UsersModel(creationData);
  
        // creation
        const createQuery = await newUser.save();
  
        // helpers func to show response
        throwResponse(res, createQuery, USER_CREATED);
      } catch (error) {
        return res.status(500).json({ success: false, error: error });
      }
    },
    async userLogin(req, res, next) {
      try {
        const { email, password } = req.body;
  
        const userGetQuery = await UsersModel.findOne({ email });
  
        if (!userGetQuery) {
          return res.status(404).json({ success: false, msg: "user not found" });
        }
  
        const { password: hashedPassword } = userGetQuery;
  
        const passwordMatch = await bcrypt.compare(password, hashedPassword);
  
        if (!passwordMatch) {
          return res
            .status(404)
            .json({ success: false, msg: "password did not matched" });
        }
  
        const token = jwt.sign(
          { id: userGetQuery._id, email },
          process.env.SECRET_KEY,
          { expiresIn: "6h" }
        );
  
        
        await UsersModel.findByIdAndUpdate(
          userGetQuery._id,
          {
            token,
          },
          { new: true }
        );
  
        return res
          .status(200)
          .json({
            success: true,
            msg: USER_LOGIN_SUCCESS,
            token,
            data: userGetQuery,
          });
      } catch (error) {
        return res.status(500).json({ success: false, error: error });
      }
    },
  };
  
  module.exports = usersController;
  