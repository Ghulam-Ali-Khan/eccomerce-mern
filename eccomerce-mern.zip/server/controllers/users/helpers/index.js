const generateHashPassword = require("../../../utilis/createHasPassword");

async function formateUserData(req) {
    const { profile_picture } = req.files;

    // converting images array to their names string array
    const profileImageFilenames = profile_picture ? profile_picture.map((image) => image.filename) : [];

    const {
        password,
        email,
        username,
        phone,
        first_name,
        last_name,
    } = req.body;


   const hashedPassword =await generateHashPassword(password);

    const finalObj = {
        profile_picture: profileImageFilenames,
        password: hashedPassword,
        email,
        username,
        phone,
        first_name,
        last_name,
    };

    if (!req?.files?.profile_picture) {
        delete finalObj.profile_picture; // Exclude cardImages from updatedData
    }

    return finalObj;
}

async function formateUserClientData(req) {
    const {
        password,
        email,
        phone,
    } = req.body;


   const hashedPassword =await generateHashPassword(password);

    const finalObj = {
        password: hashedPassword,
        email,
        phone,
    };

    return finalObj;
}

module.exports = { formateUserData, formateUserClientData };
