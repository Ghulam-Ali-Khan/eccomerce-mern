const PRODUCT_FETCHED = 'product retireved';
const USERS_FETCHED = 'users retireved';
const PRODUCT_UPDATED = 'product updation';
const PRODUCT_DELETE = 'product deleted';
const USER_CREATED = 'user created';
const USER_LOGIN_SUCCESS = 'login successfully';

module.exports = {PRODUCT_FETCHED, USERS_FETCHED, PRODUCT_UPDATED, PRODUCT_DELETE, USER_CREATED, USER_LOGIN_SUCCESS};