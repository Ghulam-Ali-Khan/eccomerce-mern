const PRODUCT_FETCHED = 'product retireved';
const PRODUCTs_FETCHED = 'products retireved';
const PRODUCT_UPDATED = 'product updation';
const PRODUCT_DELETE = 'product deleted';
const PRODUCT_CREATED = 'product retireved';


module.exports = {PRODUCT_FETCHED, PRODUCTs_FETCHED, PRODUCT_UPDATED, PRODUCT_DELETE, PRODUCT_CREATED};