const {PRODUCT_FETCHED, PRODUCTs_FETCHED, PRODUCT_UPDATED, PRODUCT_DELETE, PRODUCT_CREATED} = require('./utilis/constants');
const ProductsModel = require("@/models/products/ProductsModel");
const throwResponse = require("@/utilis/throwResponse");
const {formateProductData} = require("./helpers");
const { default: mongoose } = require('mongoose');


const productsController = {
  async createProduct(req, res, next) {
    try {
      // get already managed data obj for multiple uses
      const creationData = formateProductData(req);

      const newProduct = new ProductsModel(creationData);

      // creation
      const createQuery = await newProduct.save();

      // helpers func to show response
      throwResponse(res, createQuery, PRODUCT_CREATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async updateProduct(req, res, next) {
    try {
      // get already managed data obj for multiple uses
      const updationData = formateProductData(req);

      const updatedQuery = await ProductsModel.findByIdAndUpdate(
        req?.params?.id,
        updationData,
        { new: true }
      );

      // helpers func to show response
      throwResponse(res, updatedQuery, PRODUCT_UPDATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async deleteProduct(req, res, next) {
    try {
      const productIdsToDelete = req.body.product_ids; // Assuming you get the array of product IDs from the request body

      const deletedProducts = await ProductsModel.deleteMany({
        _id: { $in: productIdsToDelete },
      });

      // helpers func to show response
      throwResponse(res, deletedProducts.deletedCount > 0, PRODUCT_DELETE);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getAllProducts(req, res, next) {
    try {
      const { limit = process.env.DEFAULT_ITEMS_LIMIT, offset = process.env.DEFAULT_ITEMS_OFFSET, query = "", category = "", min=null, max= null } = req.query;

      const filters = {
        $and: [
          {
            $or: [
              { name: { $regex: query, $options: "i" } },
              { description: { $regex: query, $options: "i" } },
              { selling_price: isNaN(parseFloat(query)) ? 0 : parseFloat(query) },
            ],
          },
          ...(mongoose.Types.ObjectId.isValid(category) ? [{ category }] : []),
          ...(min || max ? [{ selling_price: { ...(min ? { $gte: parseFloat(min) } : {}), ...(max ? { $lte: parseFloat(max) } : {}) } }] : []),
        ],
      };

      const fetchedProducts = await ProductsModel.find(filters).skip(offset*limit).limit(limit);
  
      const totalCount = await ProductsModel.countDocuments(filters);
  
      // helpers func to show response
      throwResponse(
        res,
        fetchedProducts,
        PRODUCTs_FETCHED,
        fetchedProducts,
        totalCount
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  
  async getProductWithId(req, res, next) {
    try {

        const productId = req.params.id;

      const fetchedProduct = await ProductsModel.find({_id:productId}).populate('category');

      // helpers func to show response
      throwResponse(
        res,
        fetchedProduct,
        PRODUCT_FETCHED,
        fetchedProduct
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getProductsWithCategory(req, res, next) {
    try {
      const searchCategoryId = req.params.category_id;

      const fetchedProducts = await ProductsModel.find({
        category: searchCategoryId,
      }).populate("category").limit(process.env.DEFAULT_ITEMS_LIMIT);




      // helpers func to show response
      throwResponse(
        res,
        fetchedProducts,
        PRODUCTs_FETCHED,
        fetchedProducts,
        fetchedProducts?.length
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getProductsWithSearch(req, res, next) {
    try {
      const searchQuery = req.params.searched_string; // Assuming this is how you're getting the search query from the request body

      let fetchedProducts = null;

      if (searchQuery?.length > 0) {
         fetchedProducts = await ProductsModel.find({
          $or: [
            { name: { $regex: searchQuery, $options: "i" } }, // Case-insensitive search on name
            { description: { $regex: searchQuery, $options: "i" } }, // Case-insensitive search on description
            { price: parseFloat(searchQuery) || 0 }, // Exact match on price (convert search query to a number)
            { category: { $regex: searchQuery, $options: "i" } }, // Case-insensitive search on category
          ],
        });
      }

      // helpers func to show response
      throwResponse(
        res,
        fetchedProducts,
        PRODUCTs_FETCHED,
        fetchedProducts
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
};

module.exports = productsController;
