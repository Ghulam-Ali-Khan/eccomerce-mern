const CartModel = require("@/models/carts/CartModel");
const CartModelItem = require("@/models/carts/CartItemModel");
const OrderModel = require("@/models/orders/OrderModel");
const OrderItemsModel = require("@/models/orders/OrderItemsModel");
const ProductsModel = require("@/models/products/ProductsModel");
const throwResponse = require("@/utilis/throwResponse");
const { ORDER_CREATED, PENDING_STATUS, TODAY_KPIS, TOP_PERFORMING_PRODUCTS } = require("./utils/data");

const ordersController = {
  async createOrder(req, res, next) {
    try {
      const { id: userId } = req.params;

      const fetchedCart = await CartModel.findOneAndDelete({ user_id: userId });

      const newOrderObj = {
        user_id: userId,
        total: fetchedCart?.total,
        status: PENDING_STATUS,
      };

      const orderCreated = new OrderModel(newOrderObj);

      const createdOrderQuery = await orderCreated.save();

      const cartItemsArray = await CartModelItem.findManyAndDelete({
        cart_id: fetchedCart._id,
      }).lean();

      const orderItemsPromises = [];

      cartItemsArray.forEach((item) => {
        orderItemsPromises.push(
          new OrderItemsModel({
            ...item,
            order_id: createdOrderQuery._id,
          }).save()
        );
      });

      await Promise.all(orderItemsPromises);

      throwResponse(res, createdOrderQuery, ORDER_CREATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async todayOrderKPIs(req, res, next) {
    try {
      const now = new Date();
      const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
      const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
  
      const [result] = await OrderModel.aggregate([
        {
          $match: {
            createdAt: {
              $gte: startOfDay,
              $lt: endOfDay,
            },
          },
        },
        {
          $group: {
            _id: null,
            total: { $sum: "$total" },
            count: { $sum: 1 },
            uniqueUsers: { $addToSet: "$user_id" }
          },
        },
        {
          $project: {
            total: 1,
            count: 1,
            uniqueCustomers: { $size: "$uniqueUsers" }
          }
        }
      ]);

      const [products] = await ProductsModel.aggregate([
        {
          $group: {
            _id: null,
            total: { $sum: "$quantity" },
          },
        },
      ]);
  
      const kpis = {
        total: result ? result.total : 0,
        count: result ? result.count : 0,
        uniqueCustomers: result ? result.uniqueCustomers : 0,
        quantity: products?.total || 0,
      };
  
      throwResponse(res, result, TODAY_KPIS, kpis);
    } catch (error) {
      console.error(error);
      return res.status(500).json({ success: false, error: error.message });
    }
  },
 async topPerformings(req, res, next) {
  try {
    const bestSellersProducts = await OrderItemsModel.aggregate([
      {
        $group: {
          _id: "$product_id",
          totalQuantity: { $sum: "$quantity" },
          totalRevenue: { $sum: "$price" }, // Assuming `price` is stored in OrderItemsModel
          orderCount: { $sum: 1 }
        }
      },
      {
        $sort: { totalQuantity: -1 }
      },
      {
        $limit: 5
      },
      {
        $lookup: {
          from: "products",
          localField: "_id",
          foreignField: "_id",
          as: "productInfo"
        }
      },
      {
        $unwind: "$productInfo"
      },
      {
        $project: {
          product_id: "$_id",
          totalQuantity: 1,
          totalRevenue: 1,
          orderCount: 1,
          productInfo: 1
        }
      }
    ]);


    const bestCustomers = OrderModel.aggregate([
      {
        $group: {
          _id: "$user_id",
          totalValue: { $sum: "$total" },
          orderCount: { $sum: 1 }
        }
      },
      {
        $sort: { totalValue: -1 }
      },
      {
        $limit: 5
      },
      {
        $lookup: {
          from: "users",
          localField: "_id",
          foreignField: "_id",
          as: "customerInfo"
        }
      },
      {
        $unwind: "$customerInfo"
      },
      {
        $project: {
          user_id: "$_id",
          totalValue: 1,
          orderCount: 1,
          customerInfo: 1
        }
      }
    ]);

    const topCategories = await OrderItemsModel.aggregate([
      {
        $lookup: {
          from: "products",
          localField: "product_id",
          foreignField: "_id",
          as: "productInfo"
        }
      },
      {
        $unwind: "$productInfo"
      },
      {
        $group: {
          _id: "$productInfo.category",
          totalQuantity: { $sum: "$quantity" },
          totalRevenue: { $sum: "$price" }, // Assuming `price` is stored in OrderItemsModel
          orderCount: { $sum: 1 }
        }
      },
      {
        $sort: { totalQuantity: -1 }
      },
      {
        $limit: 5
      },
      {
        $lookup: {
          from: "categories",
          localField: "_id",
          foreignField: "_id",
          as: "categoryInfo"
        }
      },
      {
        $unwind: "$categoryInfo"
      },
      {
        $project: {
          category: "$_id",
          totalQuantity: 1,
          totalRevenue: 1,
          orderCount: 1,
          categoryInfo: 1
        }
      }
    ]);


    const [bestProducts, bestCustomersResult, topCategoriesResult] = await Promise.all([
      bestSellersProducts,
      bestCustomers,
      topCategories
    ]);

    const resultTables = {
      best_products: bestProducts,
      best_customers: bestCustomersResult,
      best_category: topCategoriesResult
    };

    throwResponse(res, resultTables, TOP_PERFORMING_PRODUCTS, resultTables);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, error: error.message });
  }
}

};

module.exports = ordersController;
