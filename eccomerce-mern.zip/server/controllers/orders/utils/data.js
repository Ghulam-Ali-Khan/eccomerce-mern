const PENDING_STATUS = "pending";
const CANCELED_STATUS = "canceled";
const DELIVERED_STATUS = "delivered";
const ON_THE_WAY_STATUS = "on the way";


// Order reponses

const ORDER_CREATED = "Order Created";
const TODAY_KPIS = "Today KPIs fetched";
const TOP_PERFORMING_PRODUCTS = "Top performings fetched";

module.exports = {ORDER_CREATED, ON_THE_WAY_STATUS, DELIVERED_STATUS, CANCELED_STATUS, PENDING_STATUS, TODAY_KPIS, TOP_PERFORMING_PRODUCTS};