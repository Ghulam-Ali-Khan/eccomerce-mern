function formateSliderData(req) {
    const { slider_imgs, } = req.files;

    // converting images array to their names string array
    const homeSliderImageFilenames = slider_imgs ? slider_imgs.map((image) => image.filename) : [];

    const {
        name,
        description,
    } = req.body;

    const finalObj = {
        slider_imgs: homeSliderImageFilenames,
        name,
        description,
    };

    if (!req?.files?.slider_imgs) {
        delete finalObj.slider_imgs; // Exclude bannerImages from updatedData
    }

    return finalObj;
}

module.exports = { formateSliderData };
