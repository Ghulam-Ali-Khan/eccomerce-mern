const SLIDER_FETCHED = 'slider retireved';
const SLIDERS_FETCHED = 'sliders retireved';
const SLIDER_UPDATED = 'slider updation';
const SLIDERS_DELETE = 'sliders deleted';
const SLIDER_CREATED = 'slider created';


module.exports = {SLIDERS_DELETE, SLIDERS_FETCHED, SLIDER_UPDATED,
     SLIDER_CREATED, SLIDER_FETCHED};