const {BLOG_FETCHED, BLOGS_FETCHED, BLOG_UPDATED, BLOG_DELETE, BLOG_CREATED} = require('./utilis/constants');
const BlogsModel = require("@/models/blogs/BlogsModel");
const throwResponse = require("@/utilis/throwResponse");
const {formateBlogData} = require("./helpers");


const blogsController = {
  async createBlog(req, res, next) {
    try {
      // get already managed data obj for multiple uses
      const creationData = formateBlogData(req);

      const newBlog= new BlogsModel(creationData);

      // creation
      const createQuery = await newBlog.save();


      // helpers func to show response
      throwResponse(res, createQuery, BLOG_CREATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async updateBlog(req, res, next) {
    try {
      // get already managed data obj for multiple uses

      const updationData = formateBlogData(req);


      const updatedQuery = await BlogsModel.findByIdAndUpdate(
        req?.params?.id,
        updationData,
        { new: true }
      );

      // helpers func to show response
      throwResponse(res, updatedQuery, BLOG_UPDATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async deleteBlog(req, res, next) {
    try {
      const blogsIdsToDelete = req.body.blogs_ids; // Assuming you get the array of product IDs from the request body

      const deletedBlogs = await BlogsModel.deleteMany({
        _id: { $in: blogsIdsToDelete },
      });

      // helpers func to show response
      throwResponse(res, deletedBlogs.deletedCount > 0, BLOG_DELETE);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getAllBlogs(req, res, next) {
    try {

      const {limit = process.env.DEFAULT_ITEMS_LIMIT , offset = process.env.DEFAULT_ITEMS_OFFSET, query="" } = req.query;

      const fetchedBlogs = await BlogsModel.find({
        $or: [
          { name: { $regex: query, $options: "i" } }, // Case-insensitive search on name
          { description: { $regex: query, $options: "i" } }, // Case-insensitive search on description
        ],
      }).populate('category').skip(offset*limit).limit(limit);

      const totalCount = await BlogsModel.countDocuments({
        $or: [
          { name: { $regex: query, $options: "i" } }, // Case-insensitive search on name
          { description: { $regex: query, $options: "i" } }, // Case-insensitive search on description
        ],
      });
      // helpers func to show response
      throwResponse(
        res,
        fetchedBlogs,
        BLOGS_FETCHED,
        fetchedBlogs,
        totalCount
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getBlogWithId(req, res, next) {
    try {

        const blogId = req.params.id;

      const fetchedBlog = await BlogsModel.find({_id:blogId});

      // helpers func to show response
      throwResponse(
        res,
        fetchedBlog,
        BLOG_FETCHED,
        fetchedBlog
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getBlogsWithSearch(req, res, next) {
    try {
      const searchQuery = req.params.searched_string; // Assuming this is how you're getting the search query from the request body

      let fetchedBlogs = null;

      if (searchQuery?.length > 0) {
        fetchedBlogs = await BlogsModel.find({
          $or: [
            { name: { $regex: searchQuery, $options: "i" } }, // Case-insensitive search on name
            { description: { $regex: searchQuery, $options: "i" } }, // Case-insensitive search on description
            { category: { $regex: searchQuery, $options: "i" } }, 
          ],
        });
      }

      // helpers func to show response
      throwResponse(
        res,
        fetchedBlogs,
        BLOGS_FETCHED,
        fetchedBlogs
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getBlogsWithCategory(req, res, next) {
    try {
      const searchQuery = req.params.category_id; // Assuming this is how you're getting the search query from the request body

      let fetchedBlogs = null;

      if (searchQuery?.length > 0) {
        fetchedBlogs = await BlogsModel.find({
          $or: [
            { category: { $regex: searchQuery, $options: "i" } }, 
          ],
        });
      }

      // helpers func to show response
      throwResponse(
        res,
        fetchedBlogs,
        BLOGS_FETCHED,
        fetchedBlogs
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
};

module.exports = blogsController;
