const { SLIDERS_FETCHED, SLIDER_UPDATED, SLIDERS_DELETE, SLIDER_CREATED, SLIDER_FETCHED} = require('./utilis/constants');
const HomeSlidersModel = require("@/models/homeSliders/HomeSlidersModel");
const throwResponse = require("@/utilis/throwResponse");
const {formateSliderData} = require("./helpers");


const homeSlidersController = {
  async createSlider(req, res, next) {
    try {
      // get already managed data obj for multiple uses
      const creationData = formateSliderData(req);

      const newSlider= new HomeSlidersModel(creationData);

      // creation
      const createQuery = await newSlider.save();


      // helpers func to show response
      throwResponse(res, createQuery, SLIDER_CREATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async updateSlider(req, res, next) {
    try {
      // get already managed data obj for multiple uses

      const updationData = formateSliderData(req);


      const updatedQuery = await HomeSlidersModel.findByIdAndUpdate(
        req?.params?.id,
        updationData,
        { new: true }
      );

      // helpers func to show response
      throwResponse(res, updatedQuery, SLIDER_UPDATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async deleteSlider(req, res, next) {
    try {
      const slidersIdsToDelete = req.body.sliders_ids; // Assuming you get the array of product IDs from the request body

      const deletedSliders = await HomeSlidersModel.deleteMany({
        _id: { $in: slidersIdsToDelete },
      });

      // helpers func to show response
      throwResponse(res, deletedSliders.deletedCount > 0, SLIDERS_DELETE);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getAllSliders(req, res, next) {
    try {

      const {limit = process.env.DEFAULT_ITEMS_LIMIT , offset = process.env.DEFAULT_ITEMS_OFFSET, query="" } = req.query;

      const fetchedSliders = await HomeSlidersModel.find({
        $or: [
          { name: { $regex: query, $options: "i" } }, // Case-insensitive search on name
          { description: { $regex: query, $options: "i" } }, // Case-insensitive search on description
        ],
      }).skip(offset*limit).limit(limit);

      const totalCount = await HomeSlidersModel.countDocuments({
        $or: [
          { name: { $regex: query, $options: "i" } }, // Case-insensitive search on name
          { description: { $regex: query, $options: "i" } }, // Case-insensitive search on description
        ],
      });
      // helpers func to show response
      throwResponse(
        res,
        fetchedSliders,
        SLIDERS_FETCHED,
        fetchedSliders,
        totalCount
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getSliderWithId(req, res, next) {
    try {

        const sliderId = req.params.id;

      const fetchedSlider = await HomeSlidersModel.find({_id:sliderId});

      // helpers func to show response
      throwResponse(
        res,
        fetchedSlider,
        SLIDER_FETCHED,
        fetchedSlider
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
};

module.exports = homeSlidersController;
