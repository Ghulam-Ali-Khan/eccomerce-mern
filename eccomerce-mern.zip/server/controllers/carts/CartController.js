const CartModel = require("@/models/carts/CartModel");
const CartModelItem = require("@/models/carts/CartItemModel");
const ProductModel = require("@/models/products/ProductsModel");
const UserModel = require("@/models/users/UsersModel");
const throwResponse = require("@/utilis/throwResponse");
const {
  PRODUCT_ADD,
  CART_RETRIVED_SUCCESSFULLY,
  PRODUCT_QUANTITY,
  PRODUCT_ITEM_REMOVED,
} = require("./utils/data");
const { transporter, mailOptions } = require("../../utilis/transporterMail");

const cartController = {
  async createCart(req, res, next) {
    try {
      
      const { cart_items: cartItems, user_id, ...restCartData } = req.body;
      const { order_from = null } = req.query;


      if(!user_id){
        return res.status(401).json({
          success: false,
          msg: `User is not logged in.`,
        });
      }

      let cart = await CartModel.findOne({ user_id: user_id }).exec();


      if (!cart) {
        const newCart = new CartModel({ user_id,  total:0 });
        cart = await newCart.save();
      }

      const productIds = cartItems.map((item) => item.product_id);


      const products = await ProductModel.find({
        _id: { $in: productIds },
      }).lean();

      const productDict = products.reduce((acc, product) => {
        acc[product._id] = product;
        return acc;
      }, {});

      let total = cart.total;
      const updateProductPromises = [];
      const saveCartItemPromises = [];

      for (const item of cartItems) {
        const product = productDict[item.product_id];

        
        if (!product) {
          throw new Error(`Product with ID ${item.product_id} not found`);
        }
        
        const productObj = await ProductModel.findById(item.product_id).exec();
        
        // Check if the item is already in the cart
        const existingCartItem = await CartModelItem.findOne({
          product_id: item.product_id,
          cart_id: cart._id,
        }).exec();
        
        if (existingCartItem) {
          return res.status(400).json({
            success: false,
            msg: `${productObj.name} is already in the cart`,
          });
        }
        
        
        if (item.quantity > product.quantity) {
          return res.status(400).json({
            success: false,
            msg: `Product ${productObj.name} quantity is less than the quantity you applied`,
          });
        }
        
        total += Number(product.selling_price) * Number(item.quantity);

        product.quantity -= Number(item.quantity);
        updateProductPromises.push(
          ProductModel.updateOne(
            { _id: product._id },
            { quantity: product.quantity }
          )
        );

        saveCartItemPromises.push(
          new CartModelItem({
            product_id: item.product_id,
            quantity: item.quantity,
            cart_id: cart._id,
            total: total,
          }).save()
        );

      }

     await CartModel.findByIdAndUpdate( cart?._id, {total: total});

      await Promise.all(updateProductPromises);
      await Promise.all(saveCartItemPromises);



      if(order_from === 'dashboard')
        {

          const userInfo = await UserModel.findById(user_id);

          transporter.sendMail(mailOptions(userInfo?.email, 'Please confirm your order!', `Dear ${userInfo?.first_name}`, 'html'), function(error, info){
            if (error) {
              console.log('Error:', error);
            } else {
              console.log('Email sent: ' + info.response);
            }
          });
    
        }

      throwResponse(res, cart, PRODUCT_ADD);
    } catch (error) {
      return res.status(500).json({ success: false, error: error, msg:'test failed' });
    }
  },
  async getCartWithId(req, res, next) {
    try {
      const userId = req.params.id;

      const fetchedCart = await CartModel.find({ user_id: userId }).lean();

      const fetchedCartItems = await CartModelItem.find({
        cart_id: fetchedCart[0]?._id,
      }).populate('product_id');

      const fetchedCartItemsCount = await CartModelItem.find({
        cart_id: fetchedCart[0]?._id,
      }).countDocuments();

      const finalData = {
        ...fetchedCart[0],
        cart_items: fetchedCartItems,
      };

      // helpers func to show response
      throwResponse(res, fetchedCart, CART_RETRIVED_SUCCESSFULLY, finalData,fetchedCartItemsCount);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async productQuantityChanger(req, res, next) {
    try {
      const cartItemId = req.params.id;
      const { quantity: quantityToChange } = req.body;

      if (quantityToChange < 1) {
        return res.status(400).json({
          success: false,
          msg: `Product quantity is less than 1 `,
        });
      }

      const fetchedCartItem = await CartModelItem.findById(cartItemId);

      const { product_id, quantity: cartQuantity } = fetchedCartItem;



      const fetchedCart = await CartModel.findById(
        fetchedCartItem?.cart_id
      ).lean();

      if (!fetchedCart) {
        return res.status(404).json({
          success: false,
          msg: "Cart not found against this id",
        });
      }

      const fetchedProduct = await ProductModel.findById(product_id);

      const { quantity: productQuantity } = fetchedProduct;

      // if (productQuantity < quantityToChange) {
      //   return res.status(400).json({
      //     success: false,
      //     msg: `applied quantity is greater than stock `,
      //   });
      // }

      const newProductQuantity = (productQuantity+cartQuantity) - Math.abs(quantityToChange);

      
      if (((productQuantity+cartQuantity) - quantityToChange) < 0) {
        return res.status(400).json({
          success: false,
          msg: `Product ${fetchedProduct.name} quantity is less than the quantity you applied`,
        });
      }
      
      const newQuantity = Math.abs(Number(quantityToChange));

      const fetchedProductObj = await ProductModel.findById(product_id);

      const totalSubtracted =
        fetchedCart.total - fetchedProductObj.selling_price * cartQuantity;

      if (totalSubtracted < 0) {
        return res.status(400).json({
          success: false,
          msg: "Cart Total is incorrect cannot proceed further",
        });
      }

      const newTotal =
        totalSubtracted + newQuantity * fetchedProductObj.selling_price;

      await CartModelItem.findByIdAndUpdate(cartItemId, {
        quantity: newQuantity,
      });

      await ProductModel.findByIdAndUpdate(product_id, {
        quantity: newProductQuantity,
      });

      const updatedCartQuantityTotal = await CartModel.findByIdAndUpdate(
        fetchedCartItem?.cart_id,
        {
          total: newTotal,
        }
      );

      throwResponse(res, updatedCartQuantityTotal, PRODUCT_QUANTITY);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async removeCartItem(req, res, next) {
    try {
      const cartItemId = req.params.id;

      const fetchedCartItem = await CartModelItem.findById(cartItemId);

      if (!fetchedCartItem) {
        return res.status(404).json({
          success: false,
          msg: "Cart Item not found against this id",
        });
      }

      const { product_id, quantity: cartQuantity } = fetchedCartItem;

      const fetchedCart = await CartModel.findById(
        fetchedCartItem?.cart_id
      ).lean();

      if (!fetchedCart) {
        return res.status(404).json({
          success: false,
          msg: "Cart not found against this id",
        });
      }

      const fetchedProduct = await ProductModel.findById(product_id);

      const { quantity: productQuantity } = fetchedProduct;

      const newProductQuantity = productQuantity + cartQuantity;

      const totalAfterSubtracted =
        fetchedCart.total - (fetchedProduct.selling_price * cartQuantity);

      if (totalAfterSubtracted < 0) {
        return res.status(400).json({
          success: false,
          msg: "Cart Total is incorrect cannot proceed further",
        });
      }

      await CartModelItem.findByIdAndDelete(cartItemId);

      await ProductModel.findByIdAndUpdate(product_id, {
        quantity: newProductQuantity,
      });

      const updatedCartQuantityTotal = await CartModel.findByIdAndUpdate(
        fetchedCartItem?.cart_id,
        {
          total: totalAfterSubtracted,
        }
      );

      throwResponse(res, updatedCartQuantityTotal, PRODUCT_ITEM_REMOVED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
};

module.exports = cartController;
