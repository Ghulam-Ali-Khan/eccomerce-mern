 const PRODUCT_ADD = "Product added";
 const PRODUCT_QUANTITY = "Product quantity updated";
 const PRODUCT_ITEM_REMOVED = "Product item removed";
 const CART_RETRIVED_SUCCESSFULLY = "Cart reterived";

 module.exports = {PRODUCT_ADD, PRODUCT_ITEM_REMOVED, PRODUCT_QUANTITY, CART_RETRIVED_SUCCESSFULLY};