function formateCompanyInfoData(req) {
    const { logo } = req?.files;

    // converting images array to their names string array
    const logoImg = logo ? logo.map((image) => image.filename) : [];

    const {
        name,
        description,
        email,
        meta_title,
        meta_description,
        meta_keywords,
        social_links
    } = req.body;

    const finalObj = {
        logo: logoImg?.filename,
        name,
        email,
        description,
        social_links,
        meta_title,
        meta_description,
        meta_keywords
    };

    if (!req?.files?.logo) {
        delete finalObj.logo; // Exclude cardImages from updatedData
    }

    return finalObj;
}

module.exports = { formateCompanyInfoData };
