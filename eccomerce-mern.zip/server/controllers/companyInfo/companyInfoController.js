const {INFO_UPDATED, INFO_FETCHED, INFO_CREATED,} = require('./utilis/constants');
const CompanyInfoModel = require("@/models/companyInfo/CompanyInfoModel");
const throwResponse = require("@/utilis/throwResponse");
const {formateCompanyInfoData} = require("./helpers");


const companyInfoController = {
  async createCompanyInfo(req, res, next) {
    try {
      // get already managed data obj for multiple uses
      const creationData = formateCompanyInfoData(req);

      const newCompanyInfo = new CompanyInfoModel(creationData);

      // creation
      const createQuery = await newCompanyInfo.save();

      // helpers func to show response
      throwResponse(res, createQuery, INFO_CREATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async updateCompanyInfo(req, res, next) {
    try {
      // get already managed data obj for multiple uses
      const updationData = formateCompanyInfoData(req);

      const updatedQuery = await CompanyInfoModel.findByIdAndUpdate(
        req?.params?.id,
        updationData,
        { new: true }
      );

      // helpers func to show response
      throwResponse(res, updatedQuery, INFO_UPDATED);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
  async getCompanyInfo(req, res, next) {
    try {
      const fetchedCompanyInfo = await CompanyInfoModel.findOne({});

      // helpers func to show response
      throwResponse(
        res,
        fetchedCompanyInfo,
        INFO_FETCHED,
        fetchedCompanyInfo
      );
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
};

module.exports = companyInfoController;
