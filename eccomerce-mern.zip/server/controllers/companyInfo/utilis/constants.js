const INFO_FETCHED = 'info retireved';
const INFO_UPDATED = 'info updation';
const INFO_CREATED = 'info created';


module.exports = {INFO_UPDATED, INFO_FETCHED, INFO_CREATED,};