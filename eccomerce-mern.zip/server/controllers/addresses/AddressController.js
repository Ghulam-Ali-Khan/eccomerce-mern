const AddressModel = require("@/models/addresses/AddressModel");
const throwResponse = require("@/utilis/throwResponse");
const { ADDRESS_ADD } = require("./utils/data");

const addressController = {
  async createAddress(req, res, next) {
    try {
      const addressValues = req.body;
      const { id: userId } = req.params;

      const addressObj = {
        ...addressValues,
        user_id: userId,
      };

      const createAddressQuery = new AddressModel(addressObj);

      const createdAddress =await createAddressQuery.save();

      throwResponse(res, createdAddress, ADDRESS_ADD, createdAddress);
    } catch (error) {
      return res.status(500).json({ success: false, error: error });
    }
  },
};

module.exports = addressController;
