const ADDRESS_ADD = "Address added";
const ADDRESS_UPDATED = "Address updated";
const ADDRESS_RETRIVED_SUCCESSFULLY = "Cart reterived";

module.exports = {ADDRESS_ADD, ADDRESS_UPDATED, ADDRESS_RETRIVED_SUCCESSFULLY};