const { Router } = require("express");
const blogsController = require("@/controllers/blogs/blogsController");
const createMulter = require("@/utilis/createMulter");
const authenticateToken = require('../../utilis/authenticateToken');

const blogsRoutes = Router();

const blogImgsUpload = createMulter("uploads/blogs");

//   fetch all
blogsRoutes.get("/all-blogs", blogsController.getAllBlogs);

// fetched one blog by id
blogsRoutes.get(
    "/blogs/:id",
    blogsController.getBlogWithId
  );

//   fetch search blogs
blogsRoutes.get(
  "/searched-blogs/:searched_string",
  blogsController.getBlogsWithSearch
);

//   fetch search blogs with categires
blogsRoutes.get(
  "/categorized-blogs/:blog_id",
  blogsController.getBlogsWithCategory
);

// blogsRoutes.use(authenticateToken);

// create
blogsRoutes.post(
  "/create-blog",
  blogImgsUpload.fields([
    { name: "card_imgs", maxCount: 5 },
    { name: "banner_imgs", maxCount: 5 },
  ]),
  blogsController.createBlog
);

// update
blogsRoutes.patch(
  "/update-blog/:id",
  blogImgsUpload.fields([
    { name: "card_imgs", maxCount: 5 },
    { name: "banner_imgs", maxCount: 5 },
  ]),
  blogsController.updateBlog
);

//  delete
blogsRoutes.delete("/delete-blog", blogsController.deleteBlog);


module.exports = blogsRoutes;
