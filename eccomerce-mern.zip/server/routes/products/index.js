const { Router } = require("express");
const productsController = require("@/controllers/products/productsController");
const createMulter = require("@/utilis/createMulter");
const authenticateToken = require('../../utilis/authenticateToken');

const productsRoutes = Router();

const productImgsUpload = createMulter("uploads/products");


//   fetch all
productsRoutes.get("/all-product", productsController.getAllProducts);

// fetched one product by id
productsRoutes.get(
    "/products/:id",
    productsController.getProductWithId
  );

  //   fetch search products with categires
productsRoutes.get(
  "/categorized-products/:category_id",
  productsController.getProductsWithCategory
);


// productsRoutes.use(authenticateToken);

// create
productsRoutes.post(
  "/create-product",
  productImgsUpload.fields([
    { name: "card_imgs", maxCount: 5 },
    { name: "banner_imgs", maxCount: 5 },
  ]),
  productsController.createProduct
);

// update
productsRoutes.patch(
  "/update-product/:id",
  productImgsUpload.fields([
    { name: "card_imgs", maxCount: 5 },
    { name: "banner_imgs", maxCount: 5 },
  ]),
  productsController.updateProduct
);

//  delete
productsRoutes.delete("/delete-product", productsController.deleteProduct);


//   fetch search products
productsRoutes.get(
  "/searched-products/:searched_string",
  productsController.getProductsWithSearch
);



module.exports = productsRoutes;
