const { Router } = require("express");
const slidersController = require("@/controllers/homeSliders/homeSlidersController");
const createMulter = require("@/utilis/createMulter");
const authenticateToken = require('../../utilis/authenticateToken');

const slidersRoutes = Router();

const sliderImgsUpload = createMulter("uploads/sliders");



slidersRoutes.get(
  "/slider/:id",
  slidersController.getSliderWithId
);

// all

slidersRoutes.get(
  "/all-slider",
  slidersController.getAllSliders
);

// slidersRoutes.use(authenticateToken);

//   create slider

slidersRoutes.post(
  "/create-slider",
  sliderImgsUpload.fields([
    { name: "slider_imgs", maxCount: 1 },
  ]),
  slidersController.createSlider
);

//   create slider

slidersRoutes.patch(
  "/update-slider/:id",
  sliderImgsUpload.fields([
    { name: "slider_imgs", maxCount: 1 },
  ]),
  slidersController.updateSlider
);


// delete

slidersRoutes.delete(
  "/delete-sliders",
  slidersController.deleteSlider
);


module.exports = slidersRoutes;
