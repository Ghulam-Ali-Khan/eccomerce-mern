const { Router } = require("express");
const ordersController = require("@/controllers/orders/OrdersController");

const ordersRoutes = Router();

// create
ordersRoutes.post(
  "/create-order/:id",
  ordersController.createOrder
);

ordersRoutes.get(
  "/today-kpis",
  ordersController.todayOrderKPIs
);

ordersRoutes.get(
  "/top-performings",
  ordersController.topPerformings
);

module.exports = ordersRoutes;
