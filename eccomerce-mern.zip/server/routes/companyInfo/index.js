const { Router } = require("express");
const companyInfoController = require("@/controllers/companyInfo/companyInfoController");
const createMulter = require("@/utilis/createMulter");
const authenticateToken = require('../../utilis/authenticateToken');

const companyInfoRoutes = Router();

const companyImgsUpload = createMulter("uploads/layout");


//   fetch 
companyInfoRoutes.get(
  "/company-info",
  companyInfoController.getCompanyInfo
);

// companyInfoRoutes.use(authenticateToken);

// create
companyInfoRoutes.post(
  "/create-info",
  companyImgsUpload.fields([
    { name: "logo", maxCount: 1 },
  ]),
  companyInfoController.createCompanyInfo
);

// update
companyInfoRoutes.patch(
  "/update-info/:id",
  companyImgsUpload.fields([
    { name: "logo", maxCount: 1 },
  ]),
  companyInfoController.updateCompanyInfo
);


module.exports = companyInfoRoutes;
