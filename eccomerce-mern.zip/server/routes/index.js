const { Router } = require('express');

const productsRoutes = require('./products');
const categoriesRoutes = require('./categories');
const blogsRoutes = require('./blogs');
const companyInfoRoutes = require('./companyInfo');
const usersRoutes = require('./users');
const clientUsersRoutes = require('./users/clientUsers');
const cartsRoutes = require('./carts');
const addressRoutes = require('./address');
const ordersRoutes = require('./orders');
const slidersRoutes = require('./sliders');


const authenticateToken = require('../utilis/authenticateToken');

const router = Router();

router.use(usersRoutes);

router.use(clientUsersRoutes);

router.use(categoriesRoutes);
router.use(productsRoutes);
router.use(blogsRoutes);
router.use(companyInfoRoutes);
router.use(slidersRoutes);
router.use(cartsRoutes);

router.use(authenticateToken);

router.use(ordersRoutes);
router.use(addressRoutes);

module.exports = router;
