const { Router } = require("express");
const addressController = require("@/controllers/addresses/AddressController");

const addressRoutes = Router();

// create
addressRoutes.post(
  "/create-address/:id",
  addressController.createAddress
);

module.exports = addressRoutes;
