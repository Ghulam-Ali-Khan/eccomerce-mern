const { Router } = require("express");
const categoriessController = require("@/controllers/categories/categoriesController");
const createMulter = require("@/utilis/createMulter");
const authenticateToken = require('../../utilis/authenticateToken');

const categoriesRoutes = Router();

const categiresImgsUpload = createMulter("uploads/categories");


// //   fetch all
categoriesRoutes.get("/all-categories", categoriessController.getAllCategories);

// // fetched one category by id
categoriesRoutes.get(
    "/categories/:id",
    categoriessController.getCategoryWithId
  );

// //   fetch search category
categoriesRoutes.get(
  "/searched-categories/:searched_string",
  categoriessController.getCategoriesWithSearch
);

categoriesRoutes.get(
    "/type-categories/:searched_string",
    categoriessController.getCategoriesWithType
  );


  // categoriesRoutes.use(authenticateToken);

// create
categoriesRoutes.post(
  "/create-category",
  categiresImgsUpload.fields([
    { name: "card_imgs", maxCount: 5 },
    { name: "banner_imgs", maxCount: 5 },
  ]),
  categoriessController.createCategory
);

// update
categoriesRoutes.patch(
  "/update-category/:id",
  categiresImgsUpload.fields([
    { name: "card_imgs", maxCount: 5 },
    { name: "banner_imgs", maxCount: 5 },
  ]),
  categoriessController.updateCategory
);

// //  delete
categoriesRoutes.delete("/delete-category", categoriessController.deleteCategory);



module.exports = categoriesRoutes;
