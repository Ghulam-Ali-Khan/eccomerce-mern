const { Router } = require("express");
const cartsController = require("@/controllers/carts/CartController");

const cartsRoutes = Router();

// create
cartsRoutes.post(
  "/create-cart",
  cartsController.createCart
);

cartsRoutes.get(
  "/cart/:id",
  cartsController.getCartWithId
);

cartsRoutes.patch(
  "/cart-quantity/:id",
  cartsController.productQuantityChanger
);

cartsRoutes.delete(
  "/cart/:id",
  cartsController.removeCartItem
);

module.exports = cartsRoutes;
