const { Router } = require("express");
const usersController = require("@/controllers/users/usersClientSideController");

const usersRoutes = Router();


// create
usersRoutes.post(
  "/client-create-user",
  usersController.createUser
);

// login
usersRoutes.post(
  "/client-login-user",
  usersController.userLogin
);


module.exports = usersRoutes;
