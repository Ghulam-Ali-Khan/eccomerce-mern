const { Router } = require("express");
const usersController = require("@/controllers/users/usersController");
const createMulter = require("@/utilis/createMulter");
const authenticateToken = require('../../utilis/authenticateToken');

const usersRoutes = Router();

const usersImgsUpload = createMulter("uploads/users");

// create
usersRoutes.post(
  "/create-user",
  usersImgsUpload.fields([
    { name: "profile_picture", maxCount: 1},
  ]),
  usersController.createUser
);

// login
usersRoutes.post(
  "/login-user",
  usersController.userLogin
);


usersRoutes.get(
  "/all-users",
  usersController.getAllUsers
);


module.exports = usersRoutes;
