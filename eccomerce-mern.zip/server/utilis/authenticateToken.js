const jwt = require('jsonwebtoken');
const UserModel = require('@/models/users/UsersModel.js'); // Assuming this is your User model

const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.sendStatus(401); // Unauthorized
  }

  try {
    const decoded = jwt.verify(token, process.env.SECRET_KEY);
  const  fetchedUser = await UserModel.findById(decoded.id); // Assuming your user id is stored in the token

    if(fetchedUser?.token === token){
      req.user = fetchedUser
    }

    next();
  } catch (error) {
    return res.sendStatus(403); // Forbidden
  }
};

module.exports = authenticateToken;