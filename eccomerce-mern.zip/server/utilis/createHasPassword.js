const bcrypt = require('bcrypt');

const generateHashPassword = async (password) => {
    try {
        const hash = await bcrypt.hash(password, parseInt(process.env.BYCRYPT_ROUNDS));
        return hash;
    } catch (error) {
        throw new Error('Error hashing password');
    }
};


module.exports = generateHashPassword;
