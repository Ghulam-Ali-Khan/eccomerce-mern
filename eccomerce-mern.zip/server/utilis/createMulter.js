const path = require('path');
const multer = require('multer');
const baseDir = process.cwd();

function createMulter(destination) {
    return multer({
      storage: multer.diskStorage({
        destination: function (req, file, cb) {
          const uploadDir = path.join(baseDir, destination);
          cb(null, uploadDir);
        },
        filename: function (req, file, cb) {
          const ext = path.extname(file.originalname);
          cb(
            null,
            file.fieldname +
              "-" +
              Date.now() +
              "-" +
              Math.round(Math.random() * 1e9) +
              ext
          );
        },
      }),
    });
}

module.exports = createMulter;
