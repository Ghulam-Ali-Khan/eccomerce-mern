function throwResponse(res, condition, msg, data = null, count = 0) {
    let responseData = {};
  
    if (data) {
      responseData = {
        data: data,
        count: count,
      };
    }
  
    if (condition) {
      return res
        .status(200)
        .json({ success: true, msg: `${msg} done successfully`, ...responseData });
    } else {
      return res.status(400).json({ success: false, msg: `${msg} failed` });
    }
  }
  
  module.exports = throwResponse;
  