import { createSlice } from '@reduxjs/toolkit';


const initialState = {
  token: typeof window !== 'undefined' && localStorage.getItem('token'),
  isAuthenticated: false,
  user:null,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    onLoggedIn: (state, action) => {



      const userDetails = { ...action.payload };

      console.log('userDetails ==> ', userDetails);

      delete userDetails.token;

      localStorage.setItem('token', action.payload.token);

      return {
        ...state,
        isAuthenticated: true,
        user: userDetails?.data,
      };
    },
  },
});

export const { onLoggedIn, } =
  authSlice.actions;
export default authSlice.reducer;
