'use client';

import { createTheme } from '@mui/material';

export const palette = {
  primary: {
    main: '#00a6fb',
    contrastText: '#ffffff',
  },
  mutedColor: {
    main: '#e7e7e7',
  },
};

const theme = createTheme({
  palette,
  breakpoints: {
    values: {
      xs: 0,
      sm: 576,
      md: 768,
      lg: 992,
      xl: 1200,
      xxl: 1400,
    },
  },
  typography: {
    fontFamily: "'Roboto', sans-serif !important",
    pageTitle: {
      fontSize: '1.3rem',
      fontWeight: 300,
      fontFamily: 'Roboto, sans-serif',

      '@media (max-width: 991px)': {
        fontSize: '1.2rem',
      },
    },
    h4: {
      fontSize: '18px !important',
      lineHeight: '24px',
    },
    h3: {
      fontSize: '24px',
      lineHeight: '32px',
    },
    h5: {
      fontSize: '14px',
    },
    h2: {
      fontSize: '30px',
      lineHeight: '36px',
    },
    linkText: {
      fontSize: '14px',
      fontWeight: 300,
      color: '#70bbfd',
      fontFamily: 'Roboto, sans-serif',

      '@media (max-width: 991px)': {
        fontSize: '12px',
      },
    },
  },
});

export default theme;