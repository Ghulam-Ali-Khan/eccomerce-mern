"use client";

import FormikField from "@shared/form/FormikField";
import React, { useCallback } from "react";
import { formSchema, initialValues } from "../utils/formUtils";
import { Button, Stack } from "@mui/material";
import FormikWrapper from "@components/common/form/FormikWrapper";
import { useLoginMutation } from "@services/public/auth";
import { onLoggedIn } from "@store/slices/authSlice";
import { useDispatch } from "react-redux";
import { useRouter } from "next/navigation";
import { createTokenCookie } from "@utilis/authCookiesManage";

function LoginForm() {
  const [doLogin] = useLoginMutation();
  const dispatch = useDispatch();
  const router = useRouter();

  const handleLogin =useCallback( async values => {
    const response = await doLogin(values);

    if (response?.data?.success) {
      createTokenCookie(response?.data);
      router.push('/admin/dashboard');
      dispatch(onLoggedIn(response?.data));
    }
  },[]);

  return (
    <FormikWrapper
      initialValues={initialValues}
      schema={formSchema}
      submitFunc={handleLogin}
    >
      <Stack spacing={1}>
        <FormikField label="Username" name="username" isStack />
        <FormikField label="Password" name="password" type="password" isPasswordField isStack />
        <br />
        <Button variant="contained" type="submit">
          LogIn
        </Button>
      </Stack>
    </FormikWrapper>
  );
}

export default LoginForm;
