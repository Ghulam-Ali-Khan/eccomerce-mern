"use client";

import React from "react";
import LoginForm from "./components/LoginForm";
import { Box, Paper } from "@mui/material";
import { COMPANY_DETAILS } from "@utilis/contants";
import Image from "next/image";

import styles from '@styles/modules/auth.module.scss';

function LoginPage() {
  return (
    <>

<Paper  className={styles.loginPageStyled}>
<Image src={COMPANY_DETAILS.logo} alt={COMPANY_DETAILS.name} width={250} />
</Paper>

      <Box display="flex" justifyContent="center" width="100%" minHeight="100vh" alignItems="center" flexDirection="column">
   

        <Box minWidth="400px" maxWidth="450px" >
          <Paper className="p-4">
            <LoginForm />
          </Paper>
        </Box>
      </Box>
    </>
  );
}

export default LoginPage;
