"use client";

import { Typography } from "@mui/material";
import SliderForm from "../components/Form";
import { useAddSliderMutation } from "@services/private/homeSliders";

// export const metadata = {
//   title: "TechSink - Silders",
//   description: "Eccomerce CRM by create next app",
// };

function SlidersAddForm() {

  const [addSlider] = useAddSliderMutation();

  return (
    <>
      <Typography variant="pageTitle">Add Slider</Typography>
      <SliderForm submitFunc={addSlider} />
    </>
  );
}

export default SlidersAddForm;
