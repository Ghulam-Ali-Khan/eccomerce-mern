export const tableHeadings = [
    {
      id: 'blog_img',
      label: 'Preview',
    },
    {
        id: 'blog_name',
        label: 'Name',
      },
      {
        id: 'description',
        label: 'Description',
      },
      {
        id: 'action',
        label: 'Action',
      },
];