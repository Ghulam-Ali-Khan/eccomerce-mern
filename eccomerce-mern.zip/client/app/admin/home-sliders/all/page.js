"use client";

import { Suspense, useMemo } from 'react';
import PropTypes from 'prop-types';

import { TableContext } from '@context/TableContext';
import withTable from '@hoc/withTable';
import SlidersTable from './components/table/SlidersTable';
import useGetSearchParams from '@customHooks/useGetSearchParams';
import { useGetHomeSlidersQuery } from '@services/private/homeSliders';

function SlidersTablePage({ tableProps }) {
  
  const apiParams = useGetSearchParams();

  const { data: slidersData, isLoading } = useGetHomeSlidersQuery(apiParams);

  const contextValues = useMemo(
    () => ({ ...tableProps, data: slidersData?.data || [], dataCount: slidersData?.count|| 0, isLoading }),
    [tableProps, slidersData, isLoading]
  );



  return (
    <>
       <Suspense fallback={<div>Loading...</div>}>
      <TableContext.Provider value={contextValues}>
        <SlidersTable />
      </TableContext.Provider>
      </Suspense>
    </>
  );
}

SlidersTablePage.propTypes = {
  tableProps: PropTypes.object.isRequired,
};

export default withTable(SlidersTablePage);
