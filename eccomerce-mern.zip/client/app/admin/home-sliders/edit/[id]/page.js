"use client";

import { Typography } from "@mui/material";
import { useEditSliderMutation } from "@services/private/homeSliders";
import SliderForm from "../../components/Form";

// export const metadata = {
//   title: "TechSink - Silders",
//   description: "Eccomerce CRM by create next app",
// };

function SlidersAddForm() {

  const [editSlider] = useEditSliderMutation();

  return (
    <>
      <Typography variant="pageTitle">Edit Slider</Typography>
      <SliderForm submitFunc={editSlider} />
    </>
  );
}

export default SlidersAddForm;
