import * as Yup from 'yup';
// eslint-disable-next-line import/prefer-default-export

const isImage = file => file && ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'].includes(file.type);

export const sliderFormInitials = {
  name: '',
  description: '',
  slider_imgs: null,
};

export const sliderFormSchema = Yup.object({
  name: Yup.string()
    .min(2, 'min 2 words required!')
    .max(100, 'max 100 words you can enter!')
    .required('Slider name required'),
    description: Yup.string()
    .min(2, 'min 2 words required!')
    .max(100, 'max 100 words you can enter!')
    .required('Alt text name required'),
    slider_imgs: Yup.mixed()
    .required('Image is required')
    // .test(
    //   'fileType',
    //   'Invalid file type, only PNG, JPEG, JPG, or WebP are allowed',
    //   isImage
    // ),
});
