'use client';

import { Box, Grid, } from '@mui/material';
import FormikField from '@shared/form/FormikField';
import { sliderFormInitials, sliderFormSchema } from './utils/formUtils';
import FormikDropzone from '@shared/form/FormikDropzone';
import FormikWrapper from '@components/common/form/FormikWrapper';
import ActionBtns from '@components/common/form/FormikActionBtns';
import StyledPaper from '@components/common/StyledPaper';
import { useParams } from 'next/navigation';
import { useGetSliderQuery } from '@services/private/homeSliders';
import { useEffect, useState } from 'react';

function SliderForm({ submitFunc }) {
    const { id } = useParams();

    const [formValues, setFormValues] = useState(sliderFormInitials);
  
    const { data: sliderData } = useGetSliderQuery(id, { skip: !id });
  
    useEffect(() => {
      if (id && sliderData?.data?.[0]) {
        setFormValues(prev => ({
          ...prev,
          ...sliderData.data[0],
        }));
      }
    }, [id, sliderData]);

    return (
        <StyledPaper>
            <FormikWrapper initialValues={formValues} schema={sliderFormSchema} submitFunc={submitFunc}>
                <Grid container spacing={2}>
                    <Grid item xl={6} lg={6} md={6} className='flex flex-col gap-6'>
                        <FormikField
                            name='name'
                            label='Slider Name'
                            placeholder='Slider Name'
                            isRequired
                        />

                    </Grid>
                    <Grid item xl={6} lg={6} md={6} className='flex flex-col gap-6'>
                        <FormikField
                            name='description'
                            label='Description'
                            placeholder='Description'
                            isRequired
                        />


                    </Grid>
                </Grid>

                <Box className="mb-3 mt-6">
                    <FormikDropzone
                        name="slider_imgs"
                        label="Slider Image"
                         moduleType="sliders"
                        isRequired
                    />
                </Box>

                <ActionBtns submitText={id ? 'Update':'Save'} resetText='Reset' initialValues={sliderFormInitials} />

            </FormikWrapper >
        </StyledPaper>
    )
}

export default SliderForm;