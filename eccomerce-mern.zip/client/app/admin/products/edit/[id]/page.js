'use client';

import { Typography } from '@mui/material'
import { useEditProductMutation } from '@services/private/products';
import ProductForm from '../../components/Form';

function ProductAddForm() {
  const [doEditProduct] = useEditProductMutation();
  return (
    <>
    <Typography
    variant='pageTitle'
    >
Edit Product
    </Typography>
<ProductForm submitFunc={doEditProduct} />
    </>
  )
}

export default ProductAddForm