export const tableHeadings = [
    {
      id: 'product_img',
      label: 'Preview',
    },
    {
        id: 'product_name',
        label: 'Name',
      },
      {
        id: 'product_retail_price',
        label: 'Retail Price',
      },
      {
        id: 'product_selling_price',
        label: 'Selling Price',
      },
      {
        id: 'product_discount',
        label: 'Discount',
      },
      {
        id: 'product_quantity',
        label: 'Stock',
      },
      {
        id: 'action',
        label: 'Action',
      },
];