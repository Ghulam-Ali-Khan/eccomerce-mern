"use client";

import { Suspense, useMemo } from 'react';
import PropTypes from 'prop-types';

import { TableContext } from '@context/TableContext';
import withTable from '@hoc/withTable';
import ProductsTable from './components/table/ProductsTable';
import { useGetProductsQuery } from '@services/private/products';
import useGetSearchParams from '@customHooks/useGetSearchParams';

function ProductsTablePage({ tableProps }) {
  
  const apiParams = useGetSearchParams();

  const { data: productsData, isLoading } = useGetProductsQuery(apiParams);

  const contextValues = useMemo(
    () => ({ ...tableProps, data: productsData?.data || [], dataCount: productsData?.count|| 0, isLoading }),
    [tableProps, productsData, isLoading]
  );



  return (
    <>
       <Suspense fallback={<div>Loading...</div>}>
      <TableContext.Provider value={contextValues}>
        <ProductsTable />
      </TableContext.Provider>
      </Suspense>
    </>
  );
}

ProductsTablePage.propTypes = {
  tableProps: PropTypes.object.isRequired,
};

export default withTable(ProductsTablePage);
