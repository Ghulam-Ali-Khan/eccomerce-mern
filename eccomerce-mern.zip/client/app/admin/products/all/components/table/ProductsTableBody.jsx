import { useTableContext } from "@context/TableContext";
import { EditNoteRounded } from "@mui/icons-material";
import {
  TableCell,
  TableRow,
  Checkbox,
  Button,
  TableBody,
  Box,
  IconButton,
} from "@mui/material";
import { IMGS_URL } from "@utilis/contants";
import Image from "next/image";
import Link from "next/link";

function ProductsTableBody() {
  const { data } = useTableContext();
  return (
    <TableBody>
      {data.map(item => {
        return (
          <TableRow role="checkbox" tabIndex={-1} key={item._id}>
            <TableCell component="td" scope="row">
              <Image
                src={`${IMGS_URL}/products/${item?.card_imgs?.[0]}`}
                alt={item.name}
                width={40}
                height={40}
              />
            </TableCell>
            <TableCell component="td" scope="row">
              <Link
                href={`detail/${item._id}`}
                className="pr-2"
              >
                {item.name}
              </Link>
            </TableCell>

            <TableCell component="td" scope="row">
              {item.retail_price}
            </TableCell>

            <TableCell component="td" scope="row">
              {item.selling_price}
            </TableCell>

            <TableCell component="td" scope="row">
              {item.discount}
            </TableCell>

            <TableCell component="td" scope="row">
              {item.quantity}
            </TableCell>

            <TableCell component="td" scope="row">
              <Link href={`edit/${item._id}`}>
                <IconButton>
                  <EditNoteRounded />
                </IconButton>
              </Link>
            </TableCell>
          </TableRow>
        );
      })}
    </TableBody>
  );
}

export default ProductsTableBody;
