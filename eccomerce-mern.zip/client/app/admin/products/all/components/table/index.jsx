import React, { useEffect, useState, useMemo, useCallback } from 'react';
import PropTypes from 'prop-types';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { Button, Toolbar, Box } from '@mui/material';

import { useGetItemsQuery } from 'services/private/items';
import MetaTagsHelmet from 'containers/common/components/MetaTagsHelmet';
import withTable from 'hoc/withTable';
import useGetParams from 'customHooks/useGetParams';
import InfoPopup from 'containers/common/components/InfoPopup';
import CommonMenu from 'containers/common/components/CommonMenu';
import { TableContext } from 'context/TableContext';
import useGetSearchParams from 'customHooks/useGetSearchParams';
import { itemFilterOptions } from '../../utils/data';
import { handleClickItem } from '../../utils/helpers';
import DeleteItemsModal from '../DeleteItemsModal';
import ItemsTable from './ItemsTable';

function ItemsMainPage({ tableProps }) {
  const { selected, setSelected, editToggle, deleteToggle, editModal, deleteModal } =
    tableProps;

  const { pathname } = useLocation();
  const navigate = useNavigate();

  const [apiParams] = useGetParams();
  const { searchParams, filter = undefined } = useGetSearchParams();

  const { data: itemsData = {}, isLoading } = useGetItemsQuery(apiParams, {
    skip: !apiParams,
  });
  const { results: items = [], count = 0 } = itemsData;

  const [selectedFilter, setFilter] = useState(itemFilterOptions[0]);

  const cantModify = useMemo(
    () => selected.length === 1 && selected[0].is_item_used,
    [selected]
  );

  const contextValues = useMemo(
    () => ({ ...tableProps, data: items, dataCount: count, isLoading }),
    [tableProps, items, isLoading, count]
  );

  const handleItemClicked = useCallback(
    item => {
      handleClickItem(item, searchParams, navigate, pathname);
    },
    [searchParams, pathname]
  );

  useEffect(() => {
    const itemFilter = itemFilterOptions.find(item => item.value === filter);
    if (filter) setFilter(itemFilter);
    else setFilter(itemFilterOptions[0]);
  }, [filter]);

  return (
    <>
      <MetaTagsHelmet moduleName="Items" />
      <InfoPopup
        isOpen={editModal}
        toggle={editToggle}
        message="This item is used in transactions, please delete them first."
      />

      {selected.length === 0 && (
        <Toolbar className="justify-content-between">
          <CommonMenu
            menus={itemFilterOptions}
            func={handleItemClicked}
            selectedOption={selectedFilter.selectedValue}
            isPageTitle
          />
          <Link to="/accounting/items/add">
            <Button size="small" color="primary" variant="contained">
              + New Item
            </Button>
          </Link>
        </Toolbar>
      )}
      {selected.length > 0 && (
        <Toolbar className="justify-content-between">
          <Box className="d-flex gap-2">
            {selected.length === 1 &&
              (cantModify ? (
                <Button
                  size="small"
                  color="primary"
                  variant="contained"
                  onClick={editToggle}
                >
                  Edit
                </Button>
              ) : (
                <Link to={`/accounting/items/${selected[0]}/edit`}>
                  <Button color="primary" variant="contained" size="small">
                    Edit
                  </Button>
                </Link>
              ))}
            <Button
              type="button"
              color="primary"
              variant="contained"
              size="small"
              onClick={() => {
                deleteToggle();
              }}
            >
              Delete
            </Button>
            <Button
              color="primary"
              variant="contained"
              size="small"
              onClick={() => setSelected([])}
            >
              Clear
            </Button>
          </Box>
          <Box className="pt-2">
            <Box className="green-bubble" /> {selected.length} item
            {selected.length > 1 && 's'} selected{' '}
          </Box>
        </Toolbar>
      )}
      <DeleteItemsModal
        deleteModal={deleteModal}
        deleteToggle={deleteToggle}
        selectedData={selected}
        setSelectedData={setSelected}
        data={items}
      />
      <TableContext.Provider value={contextValues}>
        <ItemsTable />
      </TableContext.Provider>
    </>
  );
}

ItemsMainPage.propTypes = {
  tableProps: PropTypes.object.isRequired,
};

export default withTable(ItemsMainPage);
