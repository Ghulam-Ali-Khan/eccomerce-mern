
import { TableContainer, Table, Paper, TablePagination } from "@mui/material";

import ProductsTableBody from "./ProductsTableBody";
import ProductsTableHead from "./ProductsTableHead";
import { useTableContext } from "@context/TableContext";

function ProductsTable() {
  const {
    isLoading,
    dataCount,
    rowsPerPage,
    handleChangePage,
    handleChangeRowsPerPage,
    pageNumber,
    paginationOptions,
  } = useTableContext();

  return (
    <>
      <TableContainer className="mb-2 py-2" component={Paper}>
        <Table stickyHeader>
          <ProductsTableHead />
          <ProductsTableBody />
        </Table>
        <TablePagination
          component="div"
          count={dataCount}
          rowsPerPage={rowsPerPage}
          page={pageNumber}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          rowsPerPageOptions={paginationOptions}
        />
      </TableContainer>
    </>
  );
}

export default ProductsTable;
