"use client";

import StyledPaper from "@components/common/StyledPaper"
import { Grid, Stack, Typography } from "@mui/material";
import { useGetProductQuery } from "@services/private/products"
import { DEFAULT_CURRENCY, IMGS_URL } from "@utilis/contants";
import { renderedValueWithLabel } from "@utilis/helpers";
import Image from "next/image";
import { useParams } from "next/navigation"
import { useMemo } from "react";

function ProductDetailPage() {
    const {id} = useParams();
    const {data:productData} = useGetProductQuery(id, {skip: !id});

    const product = useMemo(()=> productData?.data?.[0] ?? {},[productData]);

  return (
    <StyledPaper>
<Grid container spacing={2}>
<Grid item xl={6} lg={6} md={6}>

<Stack spacing={1} className="mb-2">

{renderedValueWithLabel(product?.name ,'Name')}
{renderedValueWithLabel(product?.category?.name ,'Category')}
{renderedValueWithLabel(`${product?.selling_price} ${DEFAULT_CURRENCY}` ,'Price')}
{renderedValueWithLabel(`${product?.retail_price} ${DEFAULT_CURRENCY}` ,'Retail Price')}
{renderedValueWithLabel(`${product?.discount} %` ,'Discount')}
{renderedValueWithLabel(`${product?.quantity} Units` ,'Stock')}
{renderedValueWithLabel(product?.description ,'Description')}
</Stack>


<Typography variant="h4" className="mb-2">
    Card Images:
</Typography>


{
    product?.banner_imgs?.length > 0 ? (
<Image
src={`${IMGS_URL}/products/${product?.card_imgs?.[0]}`}
height={100}
width={100}
alt={product?.name}
/>
    ):(
        <Typography variant="body2">
        No Banner Images
    </Typography>
    )
}
</Grid>
<Grid item xl={6} lg={6} md={6}>

<Stack spacing={1} className="mb-2">

{renderedValueWithLabel(product?.meta_title ,'Meta Title')}
{renderedValueWithLabel(product?.meta_description ,'Meta Description')}
{renderedValueWithLabel(product?.meta_keywords ,'Meta Keywords')}
</Stack>


<Typography variant="h4" className="mb-2">
    Banner Images:
</Typography>

{
    product?.banner_imgs?.length > 0 ? (
<Image
src={`${IMGS_URL}/products/${product?.banner_imgs?.[0]}`}
height={100}
width={100}
alt={product?.name}
/>
    ):(
        <Typography variant="body2">
            No Card Images
        </Typography>
    )
}

</Grid>
</Grid>
    </StyledPaper>
  )
}

export default ProductDetailPage