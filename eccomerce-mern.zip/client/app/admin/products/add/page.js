'use client';

import { Typography } from '@mui/material'
import React from 'react'
import ProductForm from '../components/Form'
import { useAddProductMutation } from '@services/private/products';

// export const metadata = {
//   title: "TechSink - Product",
//   description: "Eccomerce CRM by create next app",
// };

function ProductAddForm() {
  const [doAddProduct] = useAddProductMutation();
  return (
    <>
    <Typography
    variant='pageTitle'
    >
Add Product
    </Typography>
<ProductForm submitFunc={doAddProduct} />
    </>
  )
}

export default ProductAddForm