"use client";

import { Box, Grid } from "@mui/material";
import FormikField from "@shared/form/FormikField";
import { productFormInitials, productFormSchema } from "./utils/formUtils";
import FormikDropzone from "@shared/form/FormikDropzone";
import SEODetailsForm from "@components/common/form/SEODetailsForm";
import FormikWrapper from "@components/common/form/FormikWrapper";
import ActionBtns from "@components/common/form/FormikActionBtns";
import StyledPaper from "@components/common/StyledPaper";
import FormikSelect from "@shared/form/FormikSelect";
import { useGetCategoriresWithTypeQuery } from "@services/private/categories";
import { fetchTypes } from "@utilis/contants";
import { useEffect, useMemo, useState } from "react";
import { utilityOptionsGenerator } from "@utilis/helpers";
import { useParams } from "next/navigation";
import { useGetProductQuery } from "@services/private/products";

function ProductForm({ submitFunc }) {
  const { id } = useParams();

  const [formValues, setFormValues] = useState(productFormInitials);
  const [searchedCategory, setSearchedCategory] = useState('');

  const { data: productData } = useGetProductQuery(id, { skip: !id });
  const { data: categoriesData } = useGetCategoriresWithTypeQuery(
    {type: fetchTypes.products, query:searchedCategory}
  );

  const categoriesOptions = useMemo(
    () => utilityOptionsGenerator(categoriesData?.data),
    [categoriesData]
  );

  useEffect(() => {
    if (id && productData?.data?.[0]) {
      setFormValues(prev => ({
        ...prev,
        ...productData.data[0],
      }));
    }
  }, [id, productData]);

  return (
    <StyledPaper>
      <FormikWrapper
        initialValues={{ ...formValues }}
        schema={productFormSchema}
        submitFunc={submitFunc}
      >
        <Grid container spacing={2}>
          <Grid item xl={6} lg={6} md={6} className="flex flex-col gap-6">
            <FormikField
              name="name"
              label="Product Name"
              placeholder="Product Name"
              isRequired
            />

            <FormikField
              name="retail_price"
              label="Product Retail Price"
              placeholder="Product Retail Price"
              isRequired
            />

            <FormikField
              name="discount"
              label="Product Discount"
              placeholder="Product Discount"
              isRequired
            />

            <FormikField
              name="quantity"
              label="Product Quantity"
              placeholder="Product Quantity"
              isRequired
            />

            <FormikDropzone
              name="banner_imgs"
              label="Product Banner Image"
              moduleType="products"
              isRequired
            />
          </Grid>
          <Grid item xl={6} lg={6} md={6} className="flex flex-col gap-6">
            <FormikSelect
              name="category"
              label="Product Category"
              placeholder="Product Category"
              options={categoriesOptions}
              setSearchValue={setSearchedCategory}
              isRequired
            />

            <FormikField
              name="price"
              label="Product Selling Price"
              placeholder="Product Selling Price"
              isRequired
            />

            <FormikField
              name="profit"
              label="Product Profit"
              placeholder="Product Profit"
              isRequired
              disabled
            />

            <FormikField
              name="selling_price"
              label="Final Selling Price"
              placeholder="Final  Selling Price"
              isRequired
              disabled
            />

            <FormikDropzone
              name="card_imgs"
              moduleType="products"
              label="Product Card Image"
              isRequired
            />
          </Grid>
        </Grid>

        <Box className="mb-3 mt-6">
          <FormikField
            name="description"
            label="Product Description"
            placeholder="Product Description"
            textArea
            isStack
            isRequired
          />
        </Box>

        <SEODetailsForm />

        <ActionBtns
          submitText={id ? "Update" :"Save"}
          resetText="Reset"
          initialValues={productFormInitials}
        />
      </FormikWrapper>
    </StyledPaper>
  );
}

export default ProductForm;
