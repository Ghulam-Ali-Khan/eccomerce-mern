import * as Yup from 'yup';
// eslint-disable-next-line import/prefer-default-export

const isImage = file => file && ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'].includes(file.type);

export const productFormInitials = {
  name: '',
  category: null,
  description: '',
  price: 0,
  retail_price: 0,
discount: 0,
 profit: 0,
  quantity: 0,
  selling_price: 0,
 card_imgs: null,
  banner_imgs: null,
  meta_title: '',
  meta_description: '',
  meta_keywords: '',
};

export const productFormSchema = Yup.object({
  name: Yup.string()
    .min(2, 'min 2 words required!')
    .max(100, 'max 100 words you can enter!')
    .required('Product name required'),
  description: Yup.string()
    .min(10, 'min 10 words required!')
    .max(500, 'max 500 words you can enter!!')
    .required('Required'),
  price: Yup.number().min(0, 'min value is zero').required('Price is required'),
  discount: Yup.number()
    .min(0, 'min value is zero')
    .required('Discount is required'),
  retail_price: Yup.number()
    .min(0, 'min value is zero')
    .required('Price is required'),
  category: Yup.string().required('Category is required'),
  quantity: Yup.number()
    .min(0, 'min value is zero')
    .required('Quantity is required'),
  card_imgs: Yup.mixed()
    .required('Image is required')
    // .test(
    //   'fileType',
    //   'Invalid file type, only PNG, JPEG, JPG, or WebP are allowed',
    //   isImage
    // ),
    ,
  banner_imgs: Yup.mixed()
    .required('Image is required')
    // .test(
    //   'fileType',
    //   'Invalid file type, only PNG, JPEG, JPG, or WebP are allowed',
    //   isImage
    // ),
});
