'use client';

import Topbar from '@components/layout/components/topbar';
import Sidebar from '@components/layout/components/sidebar';
import React, { Suspense } from 'react';
import LayoutWrapper from '@components/layout';

function AdminLayout({children}) {
  return (
    <div>
{/* <Topbar/>
<Sidebar/> */}
  <Suspense fallback={<div>Loading...</div>}>
 <LayoutWrapper>
  {children}
 </LayoutWrapper>
 </Suspense>
    </div>
  )
}

export default AdminLayout;