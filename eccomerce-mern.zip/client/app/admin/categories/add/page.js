"use client";

import {Typography } from '@mui/material';
import CategoryForm from '../components/Form';
import { useAddCategoryMutation } from '@services/private/categories';

// export const metadata = {
//   title: "TechSink - Category",
//   description: "Eccomerce CRM by create next app",
// };

function CategoryAddForm() {

  const [addCategory] = useAddCategoryMutation();

  return (
    <>
    <Typography
    variant='pageTitle'
    >
Add Category
    </Typography>
<CategoryForm submitFunc={addCategory}/>
    </>
  )
}

export default CategoryAddForm;