"use client";

import {Typography } from '@mui/material';
import { useEditCategoryMutation } from '@services/private/categories';
import CategoryForm from '../../components/Form';

// export const metadata = {
//   title: "TechSink - Category",
//   description: "Eccomerce CRM by create next app",
// };

function CategoryEditForm() {

  const [editCategory] = useEditCategoryMutation();

  return (
    <>
    <Typography
    variant='pageTitle'
    >
Edit Category
    </Typography>
<CategoryForm submitFunc={editCategory}/>
    </>
  )
}

export default CategoryEditForm;