export const tableHeadings = [
    {
      id: 'category_img',
      label: 'Preview',
    },
    {
        id: 'category_name',
        label: 'Name',
      },
      {
        id: 'category_type',
        label: 'Type',
      },
      {
        id: 'action',
        label: 'Action',
      },
];