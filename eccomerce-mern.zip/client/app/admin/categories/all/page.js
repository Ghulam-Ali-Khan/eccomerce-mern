"use client";

import { Suspense, useMemo } from 'react';
import PropTypes from 'prop-types';

import { TableContext } from '@context/TableContext';
import withTable from '@hoc/withTable';
import CategoriesTable from './components/table/CategoriesTable';
// import { useGetProductsQuery } from '@services/private/products';
import useGetSearchParams from '@customHooks/useGetSearchParams';
import { useGetCategoriresQuery } from '@services/private/categories';

function CategoriesTablePage({ tableProps }) {
  
  const apiParams = useGetSearchParams();

  const { data: productsData, isLoading } = useGetCategoriresQuery(apiParams);

  const contextValues = useMemo(
    () => ({ ...tableProps, data: productsData?.data || [], dataCount: productsData?.count|| 0, isLoading }),
    [tableProps, productsData, isLoading]
  );



  return (
    <>
       <Suspense fallback={<div>Loading...</div>}>
      <TableContext.Provider value={contextValues}>
        <CategoriesTable />
      </TableContext.Provider>
      </Suspense>
    </>
  );
}

CategoriesTablePage.propTypes = {
  tableProps: PropTypes.object.isRequired,
};

export default withTable(CategoriesTablePage);
