"use client";

import StyledPaper from "@components/common/StyledPaper"
import { Grid, Stack, Typography } from "@mui/material";
import { useGetCategoryQuery } from "@services/private/categories";
import { DEFAULT_CURRENCY, IMGS_URL } from "@utilis/contants";
import { renderedValueWithLabel } from "@utilis/helpers";
import Image from "next/image";
import { useParams } from "next/navigation"
import { useMemo } from "react";

function ProductDetailPage() {
    const {id} = useParams();
    const {data:categoryData} = useGetCategoryQuery(id, {skip: !id});

    const category = useMemo(()=> categoryData?.data?.[0] ?? {},[categoryData]);

  return (
    <StyledPaper>
<Grid container spacing={2}>
<Grid item xl={6} lg={6} md={6}>

<Stack spacing={1} className="mb-2">

{renderedValueWithLabel(category?.name ,'Name')}
{renderedValueWithLabel(category?.type ,'Type')}
{renderedValueWithLabel(category?.description ,'Description')}
</Stack>


<Typography variant="h4" className="mb-2">
    Card Images:
</Typography>


{
    category?.banner_imgs?.length > 0 ? (
<Image
src={`${IMGS_URL}/categories/${category?.card_imgs?.[0]}`}
height={100}
width={100}
alt={category?.name}
/>
    ):(
        <Typography variant="body2">
        No Banner Images
    </Typography>
    )
}
</Grid>
<Grid item xl={6} lg={6} md={6}>

<Stack spacing={1} className="mb-2">

{renderedValueWithLabel(category?.meta_title ,'Meta Title')}
{renderedValueWithLabel(category?.meta_description ,'Meta Description')}
{renderedValueWithLabel(category?.meta_keywords ,'Meta Keywords')}
</Stack>


<Typography variant="h4" className="mb-2">
    Banner Images:
</Typography>

{
    category?.banner_imgs?.length > 0 ? (
<Image
src={`${IMGS_URL}/categories/${category?.banner_imgs?.[0]}`}
height={100}
width={100}
alt={category?.name}
/>
    ):(
        <Typography variant="body2">
            No Card Images
        </Typography>
    )
}

</Grid>
</Grid>
    </StyledPaper>
  )
}

export default ProductDetailPage