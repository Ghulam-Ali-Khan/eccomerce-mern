import * as Yup from 'yup';
// eslint-disable-next-line import/prefer-default-export

const isImage = file => file && ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'].includes(file.type);

export const categoryFormInitials = {
  name: '',
  type: null,
  description: '',
  card_imgs: null,
  banner_imgs: null,
  meta_title: '',
  meta_description: '',
  meta_keywords: '',
};

export const categoryFormSchema = Yup.object({
  name: Yup.string()
    .min(2, 'min 2 words required!')
    .max(100, 'max 100 words you can enter!')
    .required('Category name required'),
  description: Yup.string()
    .min(10, 'min 10 words required!')
    .max(500, 'max 500 words you can enter!!')
    .required('Required'),
  type: Yup.string().required('Category Type is required'),
  card_imgs: Yup.mixed()
    .required('Image is required')
    // .test(
    //   'fileType',
    //   'Invalid file type, only PNG, JPEG, JPG, or WebP are allowed',
    //   isImage
    // )
    ,
    banner_imgs: Yup.mixed()
    .required('Image is required')
    // .test(
    //   'fileType',
    //   'Invalid file type, only PNG, JPEG, JPG, or WebP are allowed',
    //   isImage
    // ),
});
