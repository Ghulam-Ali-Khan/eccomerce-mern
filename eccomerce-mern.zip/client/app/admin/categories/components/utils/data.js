export const options = [
    {
        label:"Blog",
        value:"blog"
    },
    {
        label:"Product",
        value:'product'
    }
];