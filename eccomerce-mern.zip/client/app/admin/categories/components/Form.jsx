"use client";

import { Box, Grid } from "@mui/material";
import FormikField from "@shared/form/FormikField";
import { categoryFormInitials, categoryFormSchema } from "./utils/formUtils";
import FormikDropzone from "@shared/form/FormikDropzone";
import SEODetailsForm from "@components/common/form/SEODetailsForm";
import FormikWrapper from "@components/common/form/FormikWrapper";
import ActionBtns from "@components/common/form/FormikActionBtns";
import StyledPaper from "@components/common/StyledPaper";
import FormikSelect from "@shared/form/FormikSelect";
import { options } from "./utils/data";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { useGetCategoryQuery } from "@services/private/categories";

function CategoryForm({ submitFunc }) {
  const { id } = useParams();

  const [formValues, setFormValues] = useState(categoryFormInitials);

  const { data: categoryData } = useGetCategoryQuery(id, { skip: !id });

  useEffect(() => {
    if (id && categoryData?.data?.[0]) {
      setFormValues(prev => ({
        ...prev,
        ...categoryData.data[0],
      }));
    }
  }, [id, categoryData]);

  return (
    <StyledPaper>
      <FormikWrapper
        initialValues={formValues}
        schema={categoryFormSchema}
        submitFunc={submitFunc}
      >
        <Grid container spacing={2}>
          <Grid item xl={6} lg={6} md={6} className="flex flex-col gap-6">
            <FormikField
              name="name"
              label="Category Name"
              placeholder="Category Name"
              isRequired
            />

            <FormikDropzone
              name="banner_imgs"
              moduleType="categories"
              label="Category Banner Image"
              isRequired
            />
          </Grid>
          <Grid item xl={6} lg={6} md={6} className="flex flex-col gap-6">
            <FormikSelect
              name="type"
              label="Category Type"
              placeholder="Category Type"
              options={options}
              isRequired
            />

            <FormikDropzone
              name="card_imgs"
              moduleType="categories"
              label="Category Card Image"
              isRequired
            />
          </Grid>
        </Grid>

        <Box className="mb-3 mt-6">
          <FormikField
            name="description"
            label="Category Description"
            placeholder="Category Description"
            textArea
            isStack
            isRequired
          />
        </Box>

        <SEODetailsForm />

        <ActionBtns
          submitText={id ? "Update" : "Save"}
          resetText="Reset"
          initialValues={categoryFormInitials}
        />
      </FormikWrapper>
    </StyledPaper>
  );
}

export default CategoryForm;
