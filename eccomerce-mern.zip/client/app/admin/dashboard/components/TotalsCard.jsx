'use client';

import { Box, Paper, Typography } from '@mui/material';
import React from 'react';
import PropTypes from 'prop-types';

function TotalsCard({ title, total, symbol, icon }) {
  return (
    <Paper className="py-3 px-4 hover:shadow-md">

      <Typography variant="h6" sx={{ fontSize: '14px', color: 'gray' }}> {title}</Typography>
      <Box className="mt-2 flex justify-between" sx={{ '& svg': { color: 'white', } }}>
        <Typography variant="h4" sx={{ fontSize: '1.4rem', fontWeight: 'bold' }}>{symbol}{total}</Typography>
        <Box className="p-2 rounded-md opacity-75" sx={{ backgroundColor: theme => theme.palette.primary.main, }}>
          {icon}
        </Box>
      </Box>
    </Paper>
  );
}

TotalsCard.propTypes = {
  title: PropTypes.string.isRequired,
  icon: PropTypes.element.isRequired,
  symbol: PropTypes.string.isRequired,
  total: PropTypes.string.isRequired,
};

export default TotalsCard;
