import React from "react";
import { TableCell, TableRow, TableBody, Stack } from "@mui/material";

import { useTableContext } from "@context/TableContext";
import Img from "@public/assets/avatar.svg";
import NoFoundTable from "@components/common/NoFoundTable";
import Image from "next/image";

function ItemsTableBody() {
  const { data, pageNumber, colSpanLength, imgPath } = useTableContext();

  if (data.length === 0) {
    return <NoFoundTable col={colSpanLength} message="No record found!" />;
  }

  return (
    <>
      <TableBody>
        {data.map((item, index) => (
          <TableRow role="checkbox" tabIndex={-1} key={index}>
            <TableCell
              component="td"
              scope="row"
              padding="none"
              width="15%"
              className="p-2"
            >
              <Image
                src={item?.img && imgPath ? `${imgPath}/${item?.img}` : Img}
                alt={item?.title}
                width={40}
                height={40}
                style={{ borderRadius: "5px" }}
              />
            </TableCell>
            <TableCell
              component="td"
              scope="row"
              padding="none"
              width="20%"
              className="fw-bold"
            >
              {item?.title}
            </TableCell>
            <TableCell component="td" scope="row" padding="none" width="20%">
              <Stack>
                <span>{item?.orders}</span>
                <span style={{ color: "gray", fontSize: "12px" }}>Orders</span>
              </Stack>
            </TableCell>

            {item?.price && (
              <TableCell component="td" scope="row" padding="none" width="20%">
                <Stack>
                  <span>
                    {" "}
                    {item?.currencySymbol} {item?.price}
                  </span>
                  <span style={{ color: "gray", fontSize: "12px" }}>Price</span>
                </Stack>
              </TableCell>
            )}

            {item?.phone && (
              <TableCell component="td" scope="row" padding="none" width="20%">
                <Stack>
                  <span>
                    {" "}
                   {item?.phone}
                  </span>
                  <span style={{ color: "gray", fontSize: "12px" }}>Phone</span>
                </Stack>
              </TableCell>
            )}

            {item?.email && (
              <TableCell component="td" scope="row" padding="none" width="20%">
                <Stack>
                  <span>
                    {" "}
                   {item?.email}
                  </span>
                  <span style={{ color: "gray", fontSize: "12px" }}>Email</span>
                </Stack>
              </TableCell>
            )}

            {item?.stock && (
              <TableCell component="td" scope="row" padding="none" width="20%">
                <Stack>
                  {item?.stock}
                  <span style={{ color: "gray", fontSize: "12px" }}>Stock</span>
                </Stack>
              </TableCell>
            )}

            <TableCell
              component="td"
              scope="row"
              padding="none"
              width="20%"
              className="p-2"
            >
              <Stack>
                {item?.total}
                <span style={{ color: "gray", fontSize: "12px" }}>
                  {item?.totalOf}
                </span>
              </Stack>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </>
  );
}

export default ItemsTableBody;
