import React from 'react';
import { TableHead, TableCell, TableRow } from '@mui/material';

import { useTableContext } from '@context/TableContext';

function ItemsTableHead() {
  const { tableHeading, colSpanLength } = useTableContext();
  return (
    <TableHead>
      <TableRow>

        <TableCell
          align="left"
          width="100%"
          className="fw-bold"
          sx={{ fontSize: '15px' }}
          colSpan={colSpanLength}
        >
          {tableHeading}
        </TableCell>
      </TableRow>
    </TableHead>
  );
}

export default ItemsTableHead;
