import React from 'react';
import { TableContainer, Table, Paper, TablePagination } from '@mui/material';

// import TableLoader from 'containers/common/components/TableLoader';
import { useTableContext } from '@context/TableContext';
import ItemsTableBody from './ItemsTableBody';
import ItemsTableHead from './ItemsTableHead';

function ItemsTable() {
  const {
    isLoading,
    dataCount,
    handleChangePage,
    pageNumber,
    colSpanLength
  } = useTableContext();

  return (
    <TableContainer component={Paper} sx={{minHeight:'350px'}}>
      <Table stickyHeader>
        <ItemsTableHead />
        {isLoading ? 
        // <TableLoader colSpan={colSpanLength} /> 
        <>Loading</>
        : <ItemsTableBody />}
      </Table>
    </TableContainer>
  );
}

export default ItemsTable;
