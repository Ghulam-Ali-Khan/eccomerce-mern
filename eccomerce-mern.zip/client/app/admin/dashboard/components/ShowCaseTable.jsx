"use client";

import React, { useMemo } from 'react';
import PropTypes from 'prop-types';

import { TableContext } from '@context/TableContext';
import withTable from '@hoc/withTable';
import ItemsTable from './table/ItemsTable';

function ShowCaseTable({ data: tableData, tableProps }) {
  const { data = [], tableHeading, imgPath } = tableData;
  const colSpanLength =  data?.col|| 6;
  const contextValues = useMemo(() => ({ ...tableProps, data, dataCount: data.length, tableHeading, colSpanLength, imgPath }), [tableProps, tableData]);
  return (
    <TableContext.Provider value={contextValues}>
      <ItemsTable />
    </TableContext.Provider>
  );
}

ShowCaseTable.propTypes = {
  data: PropTypes.array.isRequired,
  tableProps: PropTypes.object.isRequired,
};

export default withTable(ShowCaseTable);
