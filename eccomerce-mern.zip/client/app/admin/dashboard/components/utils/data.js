import {
  ImportantDevices,
  Payments,
  SentimentSatisfiedAlt,
  ShoppingCartOutlined,
} from "@mui/icons-material";
import { IMGS_URL } from "@utilis/contants";

export const totalsData = (earning, orders, customers, products) => [
  {
    symbol: "$",
    total: earning || 0,
    title: "Today Earnings",
    icon: <Payments />,
  },
  {
    symbol: "",
    total: orders || 0,
    title: "Today Orders",
    icon: <ImportantDevices />,
  },
  {
    symbol: "",
    total: customers || 0,
    title: "Today Customers",
    icon: <SentimentSatisfiedAlt />,
  },
  {
    symbol: "",
    total: products || 0,
    title: "Total Products",
    icon: <ShoppingCartOutlined />,
  },
];

export const topPerformingsTableData = (products, categories, customers) => [
  {
    tableHeading: "Best Selling Products",
    col: 6,
    data: products || [],
    imgPath: `${IMGS_URL}/products`,
  },
  {
    tableHeading: "Best Selling Categories",
    col: 6,
    data: categories || [],
    imgPath: `${IMGS_URL}/categories`,
  },
  {
    tableHeading: "Our Top Customers",
    col: 12,
    data: customers || [],
    imgPath: `${IMGS_URL}/users`,
  },
];
