export const bestSellingProducts = arrayData =>
  arrayData?.length > 0
    ? arrayData.map(item => ({
        img: item?.productInfo?.card_imgs?.[0],
        title: item?.productInfo?.name || "-",
        price: item?.productInfo?.selling_price ?? 0,
        currencySymbol: "$",
        orders: item?.orderCount ?? "-",
        total: item?.totalRevenue ?? "-",
        stock: item?.productInfo?.quantity || 0,
        totalOf: "Revenue",
      }))
    : [];

    export const bestSellingCategories = arrayData =>
        arrayData?.length > 0
          ? arrayData.map(item => ({
              img: item?.categoryInfo?.card_imgs?.[0],
              title: item?.categoryInfo?.name || "-",
              currencySymbol: "$",
              orders: item?.orderCount || "-",
              total: item?.totalRevenue || "-",
              stock: item?.totalQuantity || '-',
              totalOf: "Revenue",
            }))
          : [];

export const bestCustomers = arrayData =>
  arrayData?.length > 0
    ? arrayData.map(item => ({
        img: item?.customerInfo?.profile_picture?.[0],
        title: item?.customerInfo?.first_name || "-",
        phone: item?.customerInfo?.phone ?? '-',
        currencySymbol: "$",
        orders: item?.orderCount ?? "-",
        total: item?.totalValue ?? "-",
        email: item?.customerInfo?.email ?? '-',
        totalOf: "Revenue",
      }))
    : [];
