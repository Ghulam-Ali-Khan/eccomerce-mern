"use client";

import { Grid, Typography } from "@mui/material";
import React, { useMemo } from "react";
import TotalsCard from "./components/TotalsCard";
import { tableData, topPerformingsTableData, totalsData } from "./components/utils/data";
import ShowCaseTable from "./components/ShowCaseTable";
import {
  useGetDashboardKpisQuery,
  useGetDashboardTopPerformingsQuery,
} from "@services/private/dashboard";
import { bestCustomers, bestSellingCategories, bestSellingProducts } from "./utilis/helpers";

function DashboardPage() {
  const { data: KpiData } = useGetDashboardKpisQuery();
  const { data: topPerformingsData } = useGetDashboardTopPerformingsQuery();

  const { total, count, uniqueCustomers, quantity } = KpiData?.data || {};
  const { best_products, best_customers, best_category } = topPerformingsData?.data || {};

  const dashboardData = totalsData(total, count, uniqueCustomers, quantity);

  const bestSellingProductsArray = useMemo(
    () => bestSellingProducts(best_products),
    [best_products]
  );
  const bestCustomersArray = useMemo(
    () => bestCustomers(best_customers),
    [best_customers]
  );
  const bestCategorysArray = useMemo(
    () => bestSellingCategories(best_category),
    [best_category]
  );


  const tableDataArray = useMemo(()=> topPerformingsTableData(bestSellingProductsArray, bestCategorysArray, bestCustomersArray),
  [bestSellingProductsArray, bestCategorysArray, bestCustomersArray]);

  return (
    <>
      <Typography variant="pageTitle">Dashboard</Typography>
      <Grid
        spacing={2}
        className="mt-1 mb-4"
        sx={{ paddingRight: "1.5rem" }}
        container
      >
        {dashboardData.map((data, index) => (
          <Grid
            key={`${data.title}-${index}`}
            item
            xl={3}
            lg={3}
            md={6}
            sm={12}
          >
            <TotalsCard
              title={data.title}
              symbol={data.symbol}
              icon={data.icon}
              total={data.total}
            />
          </Grid>
        ))}

        {tableDataArray.map((data, index) => (
          <Grid
            key={`-${index}`}
            item
            xl={data.col}
            lg={data.col}
            md={data.col}
            sm={12}
          >
            <ShowCaseTable data={data} />
          </Grid>
        ))}
      </Grid>
    </>
  );
}

export default DashboardPage;
