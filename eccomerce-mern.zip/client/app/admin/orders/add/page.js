'use client';

import { Typography } from '@mui/material'
import React from 'react'
import ProductForm from '../components/Form'
import { useAddCartMutation } from '@services/private/carts';

// export const metadata = {
//   title: "TechSink - Order",
//   description: "Eccomerce CRM by create next app",
// };

function ProductAddForm() {
  const [doAddCart] = useAddCartMutation();
  return (
    <>
    <Typography
    variant='pageTitle'
    >
Add Order
    </Typography>
<ProductForm submitFunc={doAddCart} />
    </>
  )
}

export default ProductAddForm