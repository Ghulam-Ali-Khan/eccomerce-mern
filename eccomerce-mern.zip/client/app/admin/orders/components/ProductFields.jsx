import useGetThemeColor from '@customHooks/useGetThemeColor';
import { Cancel } from '@mui/icons-material';
import { Box, Grid, IconButton, Paper, Typography } from '@mui/material';
import { useGetCategoriresWithTypeQuery } from '@services/private/categories';
import { useGetProductQuery, useGetProductsQuery } from '@services/private/products';
import FormikField from '@shared/form/FormikField';
import FormikSelect from '@shared/form/FormikSelect';
import { fetchTypes } from '@utilis/contants';
import { utilityOptionsGenerator } from '@utilis/helpers';
import { useFormikContext } from 'formik';
import React, { useMemo, useState } from 'react'

function ProductFields({index = 0, remove}) {

  const primaryColor = useGetThemeColor();

  const { values } = useFormikContext();

  const [selectedCategory, setSelectedCategory] = useState("");
  const [setectedProduct, setSelectedProduct] = useState("");
  const [searchedCategory, setSearchedCategory] = useState("");
  const [searchedProduct, setSearchedProduct] = useState("");

  const products = useMemo(() => values?.cart_items, [values]);

  const {data:productData} = useGetProductQuery(setectedProduct, {skip: !setectedProduct});

  const { data: categoriesData } = useGetCategoriresWithTypeQuery({
    type: fetchTypes.products,
    query: searchedCategory,
  });
  const { data: productsData } = useGetProductsQuery({
    category: selectedCategory,
    query: searchedProduct,
  });

  
  const product = useMemo(()=> productData?.data?.[0] ?? {},[productData, values?.products]);

  const categoriesOptions = useMemo(
    () => utilityOptionsGenerator(categoriesData?.data),
    [categoriesData]
  );

  const productsOptions = useMemo(
    () => utilityOptionsGenerator(productsData?.data),
    [productsData]
  );


  return (
    <>
    {((product?.quantity > 0) && values?.cart_items?.[index]?.product_id) &&(<Box className="flex justify-end"><Typography variant="body1" 
       className="py-1 px-2 rounded-md shadow-sm max-w-fit font-bold mb-2" 
       sx={{backgroundColor: primaryColor, color: 'white'}}
       ><span style={{fontSize:'12px'}}>Stock:</span> {product?.quantity}</Typography> </Box> )}
      <Paper className="p-4 w-100  mb-2">
       
        <Box className="flex gap-2">
          <Grid container spacing={2} className="pt-2">
            <Grid item xl={4} lg={4} md={4}>
              <FormikSelect
                name={`cart_items.${index}.category`}
                label="Category"
                placeholder="Select Category"
                options={categoriesOptions}
                onChange={value => {
                  setSelectedCategory(value);
                }}
                setSearchValue={setSearchedCategory}
                isRequired
              />
            </Grid>
            <Grid item xl={4} lg={4} md={4}>
              <FormikSelect
                name={`cart_items.${index}.product_id`}
                label="Product"
                placeholder="Select Product"
                options={productsOptions}
                onChange={newValue=>{
                 if(newValue) setSelectedProduct(newValue)
                }}
                setSearchValue={setSearchedProduct}
                isRequired
              />
            </Grid>

            <Grid item xl={4} lg={4} md={4}>
              <FormikField
                name={`cart_items.${index}.quantity`}
                label="Quantity"
                placeholder="Quantity"
                type="number"
                isRequired
              />
            </Grid>
          </Grid>
          {products?.length > 1 && (
            <Box className="flex align-items-center">
              <IconButton
                variant="outlined"
                onClick={() => remove(index)}
              >
                <Cancel style={{ color: "red" }} />
              </IconButton>
            </Box>
          )}
        </Box>
      </Paper>
    </>
  )
}

export default ProductFields;