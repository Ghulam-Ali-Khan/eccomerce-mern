import * as Yup from 'yup';
// eslint-disable-next-line import/prefer-default-export

export const orderFormInitials = {
  user_id: '',
  email: '',
  cart_items:[
    {
      category:null,
      product_id:null,
      quantity:1
    }
  ]
};

export const orderFormSchema = Yup.object({
  user_id: Yup.string().required('User is required'),
  cart_items: Yup.array()
  .of(
    Yup.object({
      category: Yup.string().required('Category is required'),
      product_id: Yup.string().required('Product is required'),
      quantity: Yup.number().moreThan(0, 'Quantity must be greater than 0').required('Quantity is required')  
    })
  )
  .min(1, 'At least one product item is required')
});
