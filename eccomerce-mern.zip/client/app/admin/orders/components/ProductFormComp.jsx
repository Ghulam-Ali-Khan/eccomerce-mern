"use client";

import React, { useMemo, useState } from "react";
import { Box, Grid, IconButton, Paper, Typography } from "@mui/material";
import PropTypes from "prop-types";

import styles from "@styles/modules/btns.module.scss";
import FormikField from "@shared/form/FormikField";
import FormikSelect from "@shared/form/FormikSelect";
import { Add, Cancel } from "@mui/icons-material";
import { useFormikContext } from "formik";
import { useGetCategoriresWithTypeQuery } from "@services/private/categories";
import { fetchTypes } from "@utilis/contants";
import { utilityOptionsGenerator } from "@utilis/helpers";
import { useGetProductQuery, useGetProductsQuery } from "@services/private/products";
import useGetThemeColor from "@customHooks/useGetThemeColor";
import ProductFields from "./ProductFields";

function ProductFormComp({ push, remove }) {

  const { values } = useFormikContext();

  const products = useMemo(() => values?.cart_items, [values]);


  return (
    <>
      {products?.length > 0 &&
        products?.map((item, index) => (
            <ProductFields key={index} index={index} remove={remove}/>
        ))}

      <Box className="flex justify-end">
        <IconButton
          className={`${styles.addBtn}`}
          onClick={() =>
            push({
              category: null,
              product: null,
              quantity: 1,
            })
          }
        >
          <Add />
        </IconButton>
      </Box>
    </>
  );
}

ProductFormComp.propTypes = {
  push: PropTypes.func.isRequired,
  remove: PropTypes.func.isRequired,
};

export default ProductFormComp;
