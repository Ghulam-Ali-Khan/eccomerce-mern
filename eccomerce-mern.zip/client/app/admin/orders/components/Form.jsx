"use client";

import { Box, Grid, Typography } from "@mui/material";
import FormikField from "@shared/form/FormikField";
import { orderFormInitials, orderFormSchema } from "./utils/formUtils";
import FormikWrapper from "@components/common/form/FormikWrapper";
import ActionBtns from "@components/common/form/FormikActionBtns";
import StyledPaper from "@components/common/StyledPaper";
import FormikSelect from "@shared/form/FormikSelect";
import { useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import { useGetProductQuery } from "@services/private/products";
import { useGetUsersQuery } from "@services/private/users";
import { FieldArray } from "formik";
import ProductFormComp from "./ProductFormComp";

function ProductForm({ submitFunc }) {
  const { id } = useParams();

  const [formValues, setFormValues] = useState(orderFormInitials);
  const [searchedUser, setSearchedUser] = useState('');

  const { data: productData } = useGetProductQuery(id, { skip: !id });
  const { data: usersData } = useGetUsersQuery({query: searchedUser});

  const usersOptions = useMemo(
    () =>
      usersData?.data?.length > 0
        ? usersData?.data.map(option => ({
            label: option.username,
            value: option._id,
          }))
        : [],
    [usersData]
  );

  useEffect(() => {
    if (id && productData?.data?.[0]) {
      setFormValues(prev => ({
        ...prev,
        ...productData.data[0],
      }));
    }
  }, [id, productData]);

  return (
    <StyledPaper>
      <FormikWrapper
        initialValues={{ ...formValues }}
        schema={orderFormSchema}
        submitFunc={submitFunc}
      >
        <Grid container spacing={2}>
          <Grid item xl={6} lg={6} md={6} className="flex flex-col gap-6">
            <FormikSelect
              name="user_id"
              label="User"
              placeholder="Select User"
              options={usersOptions}
              setSearchValue={setSearchedUser}
              isRequired
            />

          </Grid>
        </Grid>

        <Box className="mb-3 mt-6">
          <FieldArray name="cart_items" component={ProductFormComp} />
        </Box>

        <ActionBtns
          submitText={id ? "Update" : "Save"}
          resetText="Reset"
          initialValues={orderFormInitials}
        />
      </FormikWrapper>
    </StyledPaper>
  );
}

export default ProductForm;
