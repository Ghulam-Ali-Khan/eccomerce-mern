import { TableHead, TableCell, TableRow, } from '@mui/material';
import { tableHeadings } from '../../utils/data';


function ProductsTableHead() {
  return (
    <TableHead>
      <TableRow>
        {tableHeadings.map(
          row => (
            <TableCell
              key={row.id}
              align="left"
            >
              {row.label}
            </TableCell>
          )
        )}
      </TableRow>
    </TableHead>
  );
}

export default ProductsTableHead;
