"use client";

import { Suspense, useMemo } from 'react';
import PropTypes from 'prop-types';

import { TableContext } from '@context/TableContext';
import withTable from '@hoc/withTable';
import BlogsTable from './components/table/BlogsTable';
import useGetSearchParams from '@customHooks/useGetSearchParams';
import { useGetBlogsQuery } from '@services/private/blogs';

function BlogsTablePage({ tableProps }) {
  
  const apiParams = useGetSearchParams();

  const { data: blogsData, isLoading } = useGetBlogsQuery(apiParams);

  const contextValues = useMemo(
    () => ({ ...tableProps, data: blogsData?.data || [], dataCount: blogsData?.count|| 0, isLoading }),
    [tableProps, blogsData, isLoading]
  );



  return (
    <>
       <Suspense fallback={<div>Loading...</div>}>
      <TableContext.Provider value={contextValues}>
        <BlogsTable />
      </TableContext.Provider>
      </Suspense>
    </>
  );
}

BlogsTablePage.propTypes = {
  tableProps: PropTypes.object.isRequired,
};

export default withTable(BlogsTablePage);
