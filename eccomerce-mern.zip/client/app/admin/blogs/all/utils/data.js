export const tableHeadings = [
    {
      id: 'blog_img',
      label: 'Preview',
    },
    {
        id: 'blog_name',
        label: 'Name',
      },
      {
        id: 'category',
        label: 'Category',
      },
      {
        id: 'action',
        label: 'Action',
      },
];