"use client";

import { Typography } from "@mui/material";
import BlogForm from "../components/Form";
import { useAddBlogMutation } from "@services/private/blogs";
import { Suspense } from "react";

// export const metadata = {
//   title: "TechSink - Blog",
//   description: "Eccomerce CRM by create next app",
// };

function BlogAddForm() {
  const [addBlog] = useAddBlogMutation();

  return (
    <>
      <Suspense fallback={<div>Loading...</div>}>
      <Typography variant="pageTitle">Add Blog</Typography>
      <BlogForm submitFunc={addBlog} />
      </Suspense>
    </>
  );
}

export default BlogAddForm;
