"use client";

import { Typography } from "@mui/material";
import { useEditBlogMutation } from "@services/private/blogs";
import BlogForm from "../../components/Form";

// export const metadata = {
//   title: "TechSink - Blog",
//   description: "Eccomerce CRM by create next app",
// };

function BlogAddForm() {
  const [editBlog] = useEditBlogMutation();

  return (
    <>
      <Typography variant="pageTitle">Edit Blog</Typography>
      <BlogForm submitFunc={editBlog} />
    </>
  );
}

export default BlogAddForm;
