"use client";

import { Box, Grid } from "@mui/material";
import FormikField from "@shared/form/FormikField";
import FormikDropzone from "@shared/form/FormikDropzone";
import SEODetailsForm from "@components/common/form/SEODetailsForm";
import FormikWrapper from "@components/common/form/FormikWrapper";
import ActionBtns from "@components/common/form/FormikActionBtns";
import StyledPaper from "@components/common/StyledPaper";
import FormikSelect from "@shared/form/FormikSelect";
import { useGetCategoriresWithTypeQuery } from "@services/private/categories";
import {
  useGetBlogQuery,
} from "@services/private/blogs";
import { utilityOptionsGenerator } from "@utilis/helpers";
import { useEffect, useMemo, useState } from "react";
import { fetchTypes } from "@utilis/contants";
import { blogFormInitials, blogFormSchema } from "./utils/formUtils";
import { useParams } from "next/navigation";

function BlogForm({ submitFunc }) {
  const { id } = useParams();

  const [formValues, setFormValues] = useState(blogFormInitials);
  const [searchedCategory, setSearchedCategory] = useState('');

  const { data: blogsData } = useGetBlogQuery(id, { skip: !id });

  const { data: categoriesData } = useGetCategoriresWithTypeQuery(
    {type: fetchTypes.blogs, query:searchedCategory}
  );

  const categoriesOptions = useMemo(
    () => utilityOptionsGenerator(categoriesData?.data),
    [categoriesData]
  );

  useEffect(() => {
    if (id && blogsData?.data?.[0]) {
      setFormValues(prev => ({
        ...prev,
        ...blogsData.data[0],
      }));
    }
  }, [id, blogsData]);

  return (
    <StyledPaper>
      <FormikWrapper
        initialValues={formValues}
        submitFunc={submitFunc}
        schema={blogFormSchema}
      >
        <Grid container spacing={2}>
          <Grid item xl={6} lg={6} md={6} className="flex flex-col gap-6">
            <FormikField
              name="name"
              label="Blog Title"
              placeholder="Blog Title"
              isRequired
            />

            <FormikDropzone
              name="banner_imgs"
              moduleType="blogs"
              label="Blog Banner Image"
              isRequired
            />
          </Grid>
          <Grid item xl={6} lg={6} md={6} className="flex flex-col gap-6">
            <FormikSelect
              name="category"
              label="Blog Category"
              placeholder="Blog Category"
              options={categoriesOptions}
              setSearchValue={setSearchedCategory}
              isRequired
            />

            <FormikDropzone
              name="card_imgs"
              moduleType="blogs"
              label="Blog Card Image"
              isRequired
            />
          </Grid>
        </Grid>

        <Box className="mb-3 mt-6">
          <FormikField
            name="description"
            label="Blog Description"
            placeholder="Blog Description"
            textArea
            isStack
            isRequired
          />
        </Box>

        <SEODetailsForm />

        <ActionBtns
          submitText={id ? "Update" : "Save"}
          resetText="Reset"
          initialValues={blogFormInitials}
        />
      </FormikWrapper>
    </StyledPaper>
  );
}

export default BlogForm;
