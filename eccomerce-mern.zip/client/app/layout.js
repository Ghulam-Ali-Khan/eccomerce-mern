import { Inter } from "next/font/google";
import "@styles/global.css";
import "@styles/global.scss";
import LayoutWrapper from "@components/layout";
import { ThemeProvider } from "@mui/material";
import theme from "@styles/mui/theme";
import ReduxProvider from "@components/common/ReduxProvider";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "TechSink - Eccomerce",
  description: "Eccomerce CRM by create next app",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ReduxProvider>
          <ThemeProvider theme={theme}>
            <LayoutWrapper>{children}</LayoutWrapper>
          </ThemeProvider>
        </ReduxProvider>
      </body>
    </html>
  );
}
