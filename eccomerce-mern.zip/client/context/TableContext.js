"use client";

import { createContext, useContext } from 'react';

export const TableContext = createContext(); // Export the TableContext

export const useTableContext = () => useContext(TableContext);
