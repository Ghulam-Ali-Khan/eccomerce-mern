/* eslint-disable react-hooks/rules-of-hooks */
"use client";

import useGetSearchParams from '@customHooks/useGetSearchParams';
import { getPaginationData } from '@utilis/helpers';
import { usePathname, useRouter } from 'next/navigation';
import React, { useEffect, useState } from 'react';

const withTable = Component => {
  const enhancedFunction = props => {
    // Make sure this code only runs on the client side
    if (typeof window === 'undefined') {
      return null;
    }

    const router = useRouter();
    const searchParams = useGetSearchParams();
    const pathname = usePathname();

    const { limit, offset } = getPaginationData(searchParams);

    const [selected, setSelected] = useState([]);

    const paginationOptions = [5, 10, 20, 50];

    const [sorting, setSorting] = useState({
      order: 'asc',
      orderBy: 'id',
    });

    useEffect(() => {
      if (selected && selected.length === 0) {
        setSorting(prevObj => ({
          ...prevObj,
          selected: new Map([]),
        }));
      }
    }, [selected]);

    const handleRequestSort = (event, property) => {
      const orderBy = property;
      let order = 'desc';

      if (sorting.orderBy === property && sorting.order === 'desc') {
        order = 'asc';
      }
      setSorting(prevObj => ({
        ...prevObj,
        order,
        orderBy,
      }));
    };

    const handleSelectAllClick = (e, data = []) => {
      if (e.target.checked) {
        const newSelected = data.map(row => row?.id);
        setSelected(newSelected);
        return;
      }
      setSelected([]);
    };

    const handleClick = (event, itemTemp) => {
      const newSelected = new Map(sorting.selected);
      const value = newSelected.get(itemTemp.id);
      let isActive = true;
      if (value) {
        isActive = false;
        setSelected(selected.filter(item => item.id !== itemTemp.id));
      } else {
        setSelected([...selected, itemTemp]);
      }
      newSelected.set(itemTemp.id, isActive);
      setSorting(prevObj => ({
        ...prevObj,
        selected: newSelected,
      }));
    };

    const handleChangePage = async (event, page) => {
      router.push(`${pathname}?limit=${limit}&offset=${+page}`);
    };

    const handleChangeRowsPerPage = async event => {
      const rowsPerPage = +event.target.value;
      router.push(`${pathname}?limit=${rowsPerPage}&offset=0`);
    };

    const { order, orderBy } = sorting;

    const isSelected = id => !!selected.find(row => row.id === id);

    const numSelected = selected.length;

    const tableProps = {
      selected,
      setSelected,
      order,
      orderBy,
      pageNumber: offset,
      rowsPerPage: limit,
      handleRequestSort,
      handleSelectAllClick,
      handleClick,
      handleChangePage,
      handleChangeRowsPerPage,
      isSelected,
      paginationOptions,
      numSelected,
    };

    return <Component tableProps={tableProps} {...props} />;
  };

  return enhancedFunction;
};

export default withTable;
