import { Box, Grid, Typography } from '@mui/material'
import FormikField from '@shared/form/FormikField'
import React from 'react'

function SEODetailsForm() {
    return (
        <>

            <Box className="my-3 mb-6">
                <Typography variant='h3' style={{ fontWeight: 600 }}>
                    SEO Details
                </Typography>
            </Box>

            <Grid container spacing={2}>
                <Grid item xl={6} lg={6} md={6} className='flex flex-col gap-6'>
                    <FormikField
                        name='meta_title'
                        label='Meta Title'
                        placeholder='Meta Title'
                        isRequired
                    />
                </Grid>
                <Grid item xl={6} lg={6} md={6} className='flex flex-col gap-6'>
                    <FormikField
                        name='meta_keywords'
                        label='Meta Keywords'
                        placeholder='Meta Keywords'
                        isRequired
                    />
                </Grid>
            </Grid>


            <Box className="mb-3 mt-6">
                <FormikField
                    name='meta_description'
                    label='Meta Description'
                    placeholder='Meta Description'
                    textArea
                    isStack
                    isRequired
                />
            </Box>

        </>
    )
}

export default SEODetailsForm;