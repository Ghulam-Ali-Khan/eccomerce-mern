import { Form, Formik } from "formik";

function FormikWrapper({
  children,
  initialValues = {},
  schema = null,
  submitFunc = null,
}) {
  return (
    <Formik
      enableReinitialize
      initialValues={initialValues}
      validationSchema={schema}
      onSubmit={async values => {
        if (submitFunc) {
        await  submitFunc(values);
        }
      }}
    >
      {({ }) => <Form>{children}</Form>}
    </Formik>
  );
}

export default FormikWrapper;
