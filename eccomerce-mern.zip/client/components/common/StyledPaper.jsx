import { Paper } from '@mui/material'

function StyledPaper({ children }) {
    return (
        <Paper className="p-4 w-100 h-100 mb-6 pt-6 mt-3 rounded-xl">
            {children}
        </Paper>
    )
}

export default StyledPaper;