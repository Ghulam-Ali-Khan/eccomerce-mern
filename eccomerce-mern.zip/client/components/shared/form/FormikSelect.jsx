import React, { useCallback, useMemo } from 'react';
import { FormHelperText, Typography, Grid, TextField, Autocomplete } from '@mui/material';
import PropTypes from 'prop-types';
import { useField } from 'formik';

const CUSTOM_BUTTON_VALUE = 'custom-menu-button';

function FormikSelect({
  name,
  options,
  disabled,
  onChange,
  onBlur,
  label,
  placeholder,
  isRequired,
  isRow,
  classes,
}) {
  const [field, meta, helpers] = useField(name || '');

  const { value, onBlur: onFieldBlur } = field;
  const { touched, error } = meta;
  const { setValue } = helpers;

  const handleChange = useCallback(selectedOption => {
    if (selectedOption && selectedOption.value === CUSTOM_BUTTON_VALUE) return;

    const fieldValue = selectedOption?.value || null;
    setValue(fieldValue);

    if (onChange) onChange(fieldValue);
  }, []);

  const handleBlur = useCallback(event => {
    onFieldBlur(event);

    if (onBlur) onBlur(name, event);
  }, []);

  const selectedOption = useMemo(
    () => options.find(option => option.value === value),
    [options, value]
  );

  return (
    <Grid className={classes} spacing={1} container>
      <Grid
        className="d-flex align-items-center"
        item
        xl={isRow ? 3 : 12}
        lg={isRow ? 3 : 12}
        md={isRow ? 4 : 12}
        sm={12}
      >
        {label && (
          <Typography
            className={isRequired ? 'required' : ''}
            variant="body2"
            sx={{ mb: '8px !important' }}
          >
            {label}
          </Typography>
        )}
      </Grid>
      <Grid sx={{ paddingTop: !isRow && '0px !important' }} item xl={isRow ? 9 : 12} lg={isRow ? 9 : 12} md={isRow ? 8 : 12} sm={12}>
        <Autocomplete
          fullWidth
          value={selectedOption}
          options={options}
          autoHighlight
          getOptionLabel={option => option.label}
          disabled={disabled}
          onChange={handleChange}
          onBlur={handleBlur}
          renderInput={params => (
            <TextField
              {...params}
              label={placeholder || 'Select Option'}
            />
          )}
          sx={{ background: disabled && '#dddddd73' }}
        />
        {touched && error && <FormHelperText error>{error}</FormHelperText>}
      </Grid>
    </Grid>
  );
}

FormikSelect.propTypes = {
  name: PropTypes.string.isRequired,
  options: PropTypes.arrayOf(PropTypes.object),
  label: PropTypes.string,
  placeholder: PropTypes.string,
  disabled: PropTypes.bool,
  menuPosition: PropTypes.string,
  menuPlacement: PropTypes.string,
  menuShouldBlockScroll: PropTypes.bool,
  isGrouped: PropTypes.bool,
  isClearable: PropTypes.bool,
  formatOptionLabel: PropTypes.func,
  onChange: PropTypes.func,
  onBlur: PropTypes.func,
  onMenuCustomButtonClick: PropTypes.func,
  menuCustomButtonLabel: PropTypes.string,
  isRequired: PropTypes.bool,
  isRow: PropTypes.bool,
  isOpen: PropTypes.bool,
  classes: PropTypes.string,
};

FormikSelect.defaultProps = {
  isOpen: undefined,
  label: '',
  options: [],
  placeholder: '',
  disabled: false,
  menuPosition: 'absolute',
  menuPlacement: 'auto',
  menuShouldBlockScroll: false,
  isGrouped: false,
  isClearable: false,
  formatOptionLabel: null,
  onChange: () => { },
  onBlur: () => { },
  onMenuCustomButtonClick: null,
  menuCustomButtonLabel: 'Add New',
  isRequired: false,
  isRow: false,
  classes: '',
};

export default FormikSelect;
