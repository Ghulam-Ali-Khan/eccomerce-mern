import React, { useCallback, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Grid, FormHelperText, Typography, useMediaQuery } from '@mui/material';
import { useField } from 'formik';
import moment from 'moment';
import { flexAlignCenter } from 'styles/mui/utilis/utilis';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';

function FormikDatePicker({
  name,
  placeholder,
  onChange,
  minDate,
  maxDate,
  disabled,
  excludeDates,
  disableFuture,
  disablePast,
  label,
  isRow,
  isRequired,
  classes,
}) {
  const isLargeScreen = useMediaQuery(theme => theme.breakpoints.up('md'));
  const [field, meta, helpers] = useField(name || '');
  const { setValue } = helpers;
  const { value } = field;
  const { error, touched } = meta;

  const [innerValue, setInnerValue] = useState(null);

  useEffect(() => {
    if (value !== '' && value !== undefined && value !== null) {
      setInnerValue(moment(value, 'YYYY-MM-DD'));
    } else {
      setInnerValue(null);
    }
  }, [value]);

  const handleChange = useCallback(
    newMoment => {
      const formattedValue = newMoment?.format('YYYY-MM-DD') || '';

      if (newMoment !== null || newMoment !== undefined) {
        setValue(formattedValue);
        setInnerValue(newMoment);
      } else {
        setValue('');
        setInnerValue('');
      }

      if (onChange) onChange(formattedValue, name);
    },
    [value]
  );

  return (
    <Grid className={classes} spacing={1} container>
      <Grid
        item
        sx={flexAlignCenter}
        xl={isRow ? 3 : 12}
        lg={isRow ? 3 : 12}
        md={isRow ? 4 : 12}
        sm={12}
      >
        {label && (
          <Typography
            className={isRequired ? 'required' : ''}
            variant="body2"
            sx={{ mb: '8px !important' }}
          >
            {label}
          </Typography>
        )}
      </Grid>
      <Grid item xl={isRow ? 9 : 12} lg={isRow ? 9 : 12} md={isRow ? 8 : 12} sm={12}>
        <LocalizationProvider dateAdapter={AdapterMoment}>
          <DatePicker
            name={name}
            value={innerValue}
            onChange={handleChange}
            disabled={disabled}
            placeholder={placeholder}
            disablePast={disablePast}
            disableFuture={disableFuture}
            minDate={minDate}
            maxDate={maxDate}
            shouldDisableDate={date => {
              let newDate = '';

              excludeDates?.forEach(item => {
                if (date.format('YYYY-MM-DD') === item) {
                  newDate = item;
                }
              });

              return !!newDate;
            }}
            desktopModeMediaQuery={
              isLargeScreen ? '@media (pointer: fine)' : '@media (pointer: coarse)'
            }
            slotProps={{ textField: { fullWidth: true } }}
          />

          {touched && error && <FormHelperText error>{error}</FormHelperText>}
        </LocalizationProvider>
      </Grid>
    </Grid>
  );
}

FormikDatePicker.propTypes = {
  name: PropTypes.string.isRequired,
  placeholder: PropTypes.string,
  label: PropTypes.string,
  minDate: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Date)]),
  maxDate: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Date)]),
  disabled: PropTypes.bool,
  onChange: PropTypes.func,
  disablePast: PropTypes.bool,
  disableFuture: PropTypes.bool,
  excludeDates: PropTypes.arrayOf(PropTypes.string),
  isRow: PropTypes.bool,
  isRequired: PropTypes.bool,
  classes: PropTypes.string,
};

FormikDatePicker.defaultProps = {
  label: '',
  placeholder: '',
  minDate: '',
  maxDate: '',
  // excludeDates: [],
  disabled: false,
  onChange: () => {},
  disablePast: false,
  disableFuture: false,
  excludeDates: [],
  isRow: false,
  isRequired: false,
  classes: null,
};

export default FormikDatePicker;
