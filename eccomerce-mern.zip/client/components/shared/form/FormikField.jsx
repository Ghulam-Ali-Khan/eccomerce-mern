"use client";

import React, { useCallback, useEffect, useState } from 'react';
import {
  TextField,
  FormHelperText,
  InputAdornment,
  IconButton,
  Typography,
  Grid,
} from '@mui/material';
import { RemoveRedEyeOutlined, VisibilityOffOutlined } from '@mui/icons-material';
// import PropTypes from 'prop-types';
import { useField, useFormikContext } from 'formik';

function FormikField({
  name,
  label,
  textArea,
  icon,
  isPasswordField,
  type,
  placeholder,
  onBlur,
  onChange,
  isRequired,
  minRows,
  disabled,
  isRow,
  classes,
}) {
  const { values } = useFormikContext();
  const [field, meta, helpers] = useField(name || '');

  const { value, onBlur: onFieldBlur, ...restField } = field;
  const { touched, error } = meta;
  const { setValue } = helpers;

  const [innerValue, setInnerValue] = useState(value || '');
  const [password, setPassword] = useState({
    show: false,
    type: 'password',
  });

  useEffect(() => {
    const timeout = setTimeout(() => {
      setValue(innerValue);
    }, 500);

    return () => clearInterval(timeout);
  }, [innerValue]);

  useEffect(() => {
    if (value !== undefined && value !== null) {
      setInnerValue(value);
    } else {
      setInnerValue('');
    }
  }, [value]);

  const handleChange = useCallback(e => {
    setInnerValue(e.target.value);

    if (onChange) onChange(e);
  }, []);

  const handleBlur = useCallback(
    e => {
      onFieldBlur(e);

      if (onBlur) onBlur(e);
    },
    [values, onBlur, innerValue]
  );

  return (
    <Grid className={classes} spacing={1} container>
      <Grid
        item
        className="d-flex align-items-center"
        xl={isRow ? 3 : 12}
        lg={isRow ? 3 : 12}
        md={isRow ? 4 : 12}
        sm={12}
      >
        {label && (
          <Typography
            className={isRequired ? 'required' : ''}
            variant="body2"
            sx={{ mb: '8px !important' }}
          >
            {label}
          </Typography>
        )}
      </Grid>
      <Grid sx={{ paddingTop: !isRow && '0px !important' }} item xl={isRow ? 9 : 12} lg={isRow ? 9 : 12} md={isRow ? 8 : 12} sm={12}>
        <TextField
          multiline={textArea}
          minRows={minRows}
          fullWidth
          {...restField}
          type={isPasswordField ? password.type : type}
          value={innerValue}
          onChange={handleChange}
          InputProps={{
            startAdornment: <InputAdornment position="start">{icon}</InputAdornment>,
            endAdornment: isPasswordField && (
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  edge="end"
                  onClick={() => {
                    setPassword(prevObj => ({
                      ...prevObj,
                      type: prevObj.show ? 'text' : 'password',
                      show: !prevObj.show,
                    }));
                  }}
                >
                  {password.show ? <RemoveRedEyeOutlined /> : <VisibilityOffOutlined />}
                </IconButton>
              </InputAdornment>
            ),
          }}
          size="small"
          onBlur={handleBlur}
          placeholder={placeholder}
          disabled={disabled}
          sx={{ background: disabled && '#dddddd73' }}
        />
        {touched && error && <FormHelperText error>{error}</FormHelperText>}
      </Grid>
    </Grid>
  );
}

// FormikField.propTypes = {
//   name: PropTypes.string.isRequired,
//   type: PropTypes.string,
//   textArea: PropTypes.bool,
//   textRight: PropTypes.bool,
//   disabled: PropTypes.bool,
//   className: PropTypes.string,
//   inputClassName: PropTypes.string,
//   placeholder: PropTypes.string,
//   label: PropTypes.string,
//   icon: PropTypes.element,
//   isPasswordField: PropTypes.bool,
//   onBlur: PropTypes.func,
//   onChange: PropTypes.func,
//   isRequired: PropTypes.bool,
//   minRows: PropTypes.number,
//   classes: PropTypes.string,
//   isRow: PropTypes.bool,
// };

// FormikField.defaultProps = {
//   type: 'text',
//   minRows: 3,
//   textArea: false,
//   textRight: false,
//   disabled: false,
//   icon: null,
//   className: '',
//   inputClassName: '',
//   placeholder: '',
//   onChange: () => { },
//   onBlur: () => { },
//   label: '',
//   isPasswordField: false,
//   isRequired: false,
//   classes: '',
//   isRow: false,
// };

export default FormikField;
