import React, { useCallback, } from 'react';
import {
  FormHelperText,
  Typography,
  Grid,
} from '@mui/material';
import BackupOutlinedIcon from '@mui/icons-material/BackupOutlined';
import PropTypes from 'prop-types';
import { useField, useFormikContext } from 'formik';

function FormikDropzone({
  name,
  label,
  onBlur,
  onChange,
  isRequired,
  disabled,
  isRow,
  classes,
  isSimple
}) {
  const { values } = useFormikContext();
  const [field, meta, helpers] = useField(name || '');

  const { value, onBlur: onFieldBlur, } = field;
  const { touched, error } = meta;
  const { setValue } = helpers;

  const styling = {
    border: '1px solid #ddd',
    borderRadius: '5px',
    cursor: 'pointer',
    height: '150px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  };

  const handleChange = useCallback(e => {
    setValue(e.target.files[0]);

    if (onChange) onChange(e);
  }, []);

  const handleBlur = useCallback(
    e => {
      onFieldBlur(e);

      if (onBlur) onBlur(e);
    },
    [values, onBlur,]
  );

  console.log('value banner :', value);

  return (
    <Grid className={classes} spacing={1} container>
      <Grid
        item
        className="d-flex align-items-center"
        xl={isRow ? 3 : 12}
        lg={isRow ? 3 : 12}
        md={isRow ? 4 : 12}
        sm={12}
      >
        {label && (
          <Typography
            className={isRequired ? 'required' : ''}
            variant="body2"
            sx={{ mb: '8px !important' }}
          >
            {label}
          </Typography>
        )}
      </Grid>
      <Grid sx={{ paddingTop: !isRow && '0px !important' }} item xl={isRow ? 9 : 12} lg={isRow ? 9 : 12} md={isRow ? 8 : 12} sm={12}>
        {value && <img src={URL.createObjectURL(value)} style={{ width: 60, border: '1px solid #ddd', marginBottom: '5px' }} alt="" />}
        <label
          htmlFor={name}
          style={{
            width: '100%',
            ...(isSimple ? {} : styling), // Conditionally apply additional styles if `isSimple` is false
          }}
          className={`${!isSimple ? 'dropzone-hover' : ''} ${classes}`}
        >
          {!isSimple && (
            <Typography variant="body1" sx={{ color: '#ddd' }}>
              Choose file <BackupOutlinedIcon />
            </Typography>
          )}
          <input
            className={!isSimple && 'd-none'}
            name={name}
            id={name}
            type="file"
            disabled={disabled}
            onChange={handleChange}
            onBlur={handleBlur}
          />
        </label>

        {touched && error && <FormHelperText error>{error}</FormHelperText>}
      </Grid>
    </Grid>
  );
}

FormikDropzone.propTypes = {
  name: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
  label: PropTypes.string,
  onBlur: PropTypes.func,
  onChange: PropTypes.func,
  isRequired: PropTypes.bool,
  classes: PropTypes.string,
  isRow: PropTypes.bool,
  isSimple: PropTypes.bool,
};

FormikDropzone.defaultProps = {
  disabled: false,
  onChange: () => { },
  onBlur: () => { },
  label: '',
  isRequired: false,
  classes: '',
  isRow: false,
  isSimple: false
};

export default FormikDropzone;
