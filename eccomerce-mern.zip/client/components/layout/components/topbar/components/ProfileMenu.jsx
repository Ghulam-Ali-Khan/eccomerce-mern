import useGetMenuUtilis from "@customHooks/useGetMenuUtilis";
import { KeyboardArrowDown } from "@mui/icons-material";
import { Avatar, Button, Menu, MenuItem, Typography } from "@mui/material";
import Ava from "@public/assets/avatar.svg";

import styles from "@styles/modules/layout.module.scss";
import { deleteTokenCookie } from "@utilis/authCookiesManage";
import { COMPANY_DETAILS } from "@utilis/contants";
import { useRouter } from "next/navigation";

function ProfileMenu() {
  const { anchorEl, handleClick, handleClose } = useGetMenuUtilis();

  const router = useRouter();

  return (
    <>
      <Button
        className={`${styles.profileBtn} flex gap-2 align-items-center`}
        onClick={handleClick}
        endIcon={<KeyboardArrowDown />}
      >
        <Avatar
          src={Ava.src}
          className={styles.avatar}
          alt={COMPANY_DETAILS.name}
        />
        <Typography variant="body1">Ghulam Ali</Typography>
      </Button>

      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={anchorEl}
        onClose={handleClose}
        MenuListProps={{
          "aria-labelledby": "basic-button",
        }}
      >
        <MenuItem onClick={handleClose}>Profile</MenuItem>
        <MenuItem onClick={handleClose}>My account</MenuItem>
        <MenuItem
          onClick={() => {
            handleClose();
            deleteTokenCookie();
            router.push('/admin/login');
          }}
        >
          Logout
        </MenuItem>
      </Menu>
    </>
  );
}

export default ProfileMenu;
