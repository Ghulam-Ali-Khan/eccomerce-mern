'use client';

import { Suspense } from 'react';
import { Box, Paper } from '@mui/material';

// Styles
import styles from '@styles/modules/layout.module.scss';

// Componnets
import ProfileMenu from './components/ProfileMenu';
import SearchField from '@shared/components/SearchField';

function Topbar() {
  return (
    <Paper className={styles.topbar} elevation={4} >

      <Box className="flex justify-between w-full">
      <Suspense fallback={<div>Loading...</div>}>
        <Box className="ml-3">
          <SearchField />
        </Box>
        </Suspense>
        <ProfileMenu />
      </Box>
    </Paper >
  );
}

export default Topbar;
