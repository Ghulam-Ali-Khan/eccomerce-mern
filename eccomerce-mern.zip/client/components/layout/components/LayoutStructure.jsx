"use client";

import React from "react";
import { Box, Grid } from "@mui/material";
import Topbar from "./topbar";
import Sidebar from "./sidebar";

function LayoutStructure({ children }) {
  return (

    <Box>
      <Topbar />
      <Grid spacing={2} container>
        <Grid item xl={2} lg={2} md={3}>
          <Sidebar />
        </Grid>
        <Grid
          item
          xl={10}
          lg={10}
          md={9}
          sx={{ paddingRight: "15px", marginTop: "5.5rem" }}
        >
          {children}
        </Grid>
      </Grid>
    </Box>
  );
}

export default LayoutStructure;
