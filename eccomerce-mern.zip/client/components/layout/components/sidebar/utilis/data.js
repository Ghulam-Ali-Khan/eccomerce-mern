/* eslint-disable react/jsx-filename-extension */
/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable import/prefer-default-export */
import {
  SpaceDashboardRounded,
  CategoryRounded,
  PrecisionManufacturingRounded,
  BurstModeRounded,
  AddCircleRounded,
  CalculateRounded,
  ShoppingCartRounded,
  MenuOpenRounded,
  WidgetsRounded,
  WebStoriesRounded,
  BallotRounded,
} from '@mui/icons-material';

export const sidebarLinks = [
  {
    path: '/admin/dashboard/',
    title: 'Dashboard',
    icon: <SpaceDashboardRounded />,
  },
  {
    path: null,
    title: 'Products',
    icon: <PrecisionManufacturingRounded />,
    data: [
      {
        path: '/admin/products/add',
        title: 'Add Product',
        icon: <AddCircleRounded />,
      },
      {
        path: '/admin/products/all',
        title: 'All Products',
        icon: <BallotRounded />,
      },
    ],
  },
  {
    path: null,
    title: 'Categories',
    icon: <CategoryRounded />,
    data: [
      {
        path: '/admin/categories/add',
        title: 'Add Category',
        icon: <AddCircleRounded />,
      },
      {
        path: '/admin/categories/all',
        title: 'All Categories',
        icon: <BallotRounded />,
      },
    ],
  },
  {
    path: null,
    title: 'Home Sliders',
    icon: <BurstModeRounded />,
    data: [
      {
        path: '/admin/home-sliders/add',
        title: 'Add Slider',
        icon: <AddCircleRounded />,
      },
      {
        path: '/admin/home-sliders/all',
        title: 'All Sliders',
        icon: <BallotRounded />,
      },
    ],
  },
  {
    path: null,
    title: 'Blogs',
    icon: <WebStoriesRounded />,
    data: [
      {
        path: '/admin/blogs/add',
        title: 'Add Blog',
        icon: <AddCircleRounded />,
      },
      {
        path: '/admin/blogs/all',
        title: 'All Blogs',
        icon: <BallotRounded />,
      },
    ],
  },
  {
    path: null,
    title: 'Orders',
    icon: <ShoppingCartRounded />,
    data: [
      {
        path: '/admin/orders/add',
        title: 'Add Order',
        icon: <AddCircleRounded />,
      },
      {
        path: '/admin/orders',
        title: 'All Orders',
        icon: <BallotRounded />,
      },
    ],
  },
  // {
  //   path: null,
  //   title: 'Menus',
  //   icon: <MenuOpenRounded />,
  //   data: [
  //     {
  //       path: '/menus/add',
  //       title: 'Add Menu',
  //       icon: <AddCircleRounded />,
  //     },
  //     {
  //       path: '/menus',
  //       title: 'All Menus',
  //       icon: <BallotRounded />,
  //     },
  //   ],
  // },
  // {
  //   path: '/components',
  //   title: 'Components',
  //   icon: <WidgetsRounded />,
  // },
];
