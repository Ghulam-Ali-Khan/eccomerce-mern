import { ListItemButton, ListItemIcon, ListItemText } from '@mui/material';
import PropTypes from 'prop-types';
import Link from 'next/link';

function SidebarItem({ title = "", icon = null, path = "/" }) {
  return (
    <Link href={path}>
      <ListItemButton>
        {
          icon && (<ListItemIcon>
            {icon}
          </ListItemIcon>)
        }
        {title && (<ListItemText primary={title} />)}
      </ListItemButton>
    </Link>
  );
}

SidebarItem.propTypes = {
  title: PropTypes.string,
  icon: PropTypes.any,
  path: PropTypes.string,
};

export default SidebarItem;
