'use client';

import React, { useCallback, useState } from 'react';
import { ExpandLess, ExpandMore } from '@mui/icons-material';
import { Collapse, List, ListItemButton, ListItemIcon, ListItemText } from '@mui/material';
import PropTypes from 'prop-types';
import SidebarItem from './SidebarItem';

function NestedSidebarItems({ data, icon, title }) {
  const [open, setOpen] = useState(false);

  const handleClick = useCallback(() => {
    setOpen(!open);
  }, [open]);

  return (
    <>
      <ListItemButton onClick={handleClick}>
        <ListItemIcon>
          {icon}
        </ListItemIcon>
        <ListItemText primary={title} />
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItemButton>

      <Collapse in={open}>
        <List component="div" disablePadding>
          {
            data.map((menu, index) => {
              if (menu?.data) {
                return <NestedSidebarItems data={menu.data} title={menu.title} icon={menu.icon} key={index} />;
              }
              return (
                <SidebarItem path={menu.path} title={menu.title} icon={menu.icon} key={menu.path} />
              );
            })
          }
        </List>
      </Collapse>
    </>
  );
}

NestedSidebarItems.propTypes = {
  data: PropTypes.array.isRequired,
  icon: PropTypes.element.isRequired,
  title: PropTypes.string.isRequired,
};

export default NestedSidebarItems;
