'use client';

import React from 'react';
import { Box, List } from '@mui/material';

// import styles from 'styles/common/layout.module.scss';
import { sidebarLinks } from './utilis/data';
import NestedSidebarItems from './components/NestedSidebarItems';
import SidebarItem from './components/SidebarItem';
import styles from '@styles/modules/layout.module.scss';
import Link from 'next/link';
import Image from 'next/image';
import { COMPANY_DETAILS } from '@utilis/contants';

function Sidebar() {
  return (
    <>

      <List
        className={styles.sidebar}
        variant="sidebar"
        component="nav"
      >
        <Box className={styles.logo}>
          <Link href='/' >
            <Image
              src={COMPANY_DETAILS.whiteLogo}
              width={200}
              alt={COMPANY_DETAILS.name}
            />
          </Link>
        </Box>
        {
          sidebarLinks.map((menu, index) => {
            if (menu?.data) {
              return <NestedSidebarItems data={menu.data} title={menu.title} icon={menu.icon} key={index} />;
            }
            return <SidebarItem title={menu.title} icon={menu.icon} path={menu.path} key={menu.path} />;
          })
        }
      </List>
    </>
  );
}

export default Sidebar;
