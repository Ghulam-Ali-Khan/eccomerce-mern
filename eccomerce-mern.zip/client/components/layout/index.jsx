"use client";

import React from "react";
import LayoutStructure from "./components/LayoutStructure";
import { usePathname } from "next/navigation";

function LayoutWrapper({ children }) {
  const pathname = usePathname();

  const isAdminRoute = pathname?.includes("admin");

  if(!isAdminRoute){
        return children;
  }

  return(
    <LayoutStructure>{children}</LayoutStructure>
  );
}

 export default LayoutWrapper;
