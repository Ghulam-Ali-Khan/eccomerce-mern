import { publicAPI } from './index';

export const authAPI = publicAPI.injectEndpoints({
  endpoints: build => ({
    login: build.mutation({
      query: payload => ({
        url: '/login-user',
        method: 'POST',
        body: {
          ...payload,
        },
      }),
    }),
    resetPasswordEmail: build.mutation({
      query: values => {
        const { email } = values;
        // const body = JSON.stringify({ email });
        // const responseStatus = '';

        return {
          url: '/auth/forgotpassword',
          method: 'POST',
          body: { email },
        };
      },
    }),
    changeUserPassword: build.mutation({
      query: values => {
        const body = values;
        // const body = JSON.stringify({ email });
        // const responseStatus = '';

        return {
          url: '/auth/pasword',
          method: 'PATCH',
          body,
        };
      },
    }),
  }),
});

export const { useLoginMutation, useResetPasswordEmailMutation, useChangeUserPasswordMutation } = authAPI;
