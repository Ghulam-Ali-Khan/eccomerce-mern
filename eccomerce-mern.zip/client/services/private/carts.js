import { privateAPI } from './index';

export const cartsAPI = privateAPI.injectEndpoints({
  endpoints: build => ({
    addCart: build.mutation({
      query: values => {

        return{
        url: '/create-cart?order_from=dashboard',
        method:'POST',
        body: values,
     };
    },
    invalidatesTags:['CartsList']
    }),
  }),
});

export const {
useAddCartMutation,
} = cartsAPI;
