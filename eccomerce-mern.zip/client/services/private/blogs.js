import { appendFormDataWithImgs } from '@utilis/helpers';
import { privateAPI } from './index';

export const blogsAPI = privateAPI.injectEndpoints({
  endpoints: build => ({
    addBlog: build.mutation({
      query: values => {

        const modifiedFormData =  appendFormDataWithImgs(values);

        return{
        url: '/create-blog',
        method:'POST',
        body: modifiedFormData,
     };
    },
    invalidatesTags:['BlogsList']
    }),
    editBlog: build.mutation({
      query: values => {

      const modifiedFormData =  appendFormDataWithImgs(values);

        return{
        url: `/update-blog/${values._id}`,
        method:'PATCH',
        body: modifiedFormData,
     };
    },
     invalidatesTags:['BlogsList']
    }),
    getBlogs: build.query({
      query: params => {
        return{
        url: `/all-blogs`  ,
        method:'GET',
        params
     };
    },
    providesTags:['BlogsList']
    }),
    getBlog: build.query({
      query: id => {
        return{
        url: `/blogs/${id}`,
        method:'GET',
     }; 
    },
    }),
  }),
});

export const {
useAddBlogMutation,
useEditBlogMutation,
useGetBlogsQuery,
useGetBlogQuery
} = blogsAPI;
