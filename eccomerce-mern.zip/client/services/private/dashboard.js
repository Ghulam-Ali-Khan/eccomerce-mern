import { privateAPI } from './index';

export const dashboardAPI = privateAPI.injectEndpoints({
  endpoints: build => ({
    getDashboardKpis: build.query({
      query: params => {
        return{
        url: `/today-kpis`  ,
        method:'GET',
     };
    },
    providesTags:['UsersList']
    }),
    getDashboardTopPerformings: build.query({
        query: () => {
          return{
          url: `/top-performings`  ,
          method:'GET',
       };
      },
      providesTags:['UsersList']
      }),
  }),
});

export const {
useGetDashboardKpisQuery,
useGetDashboardTopPerformingsQuery
} = dashboardAPI;
