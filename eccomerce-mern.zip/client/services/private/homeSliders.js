import { appendFormDataWithImgs } from '@utilis/helpers';
import { privateAPI } from './index';

export const homeSlidersAPI = privateAPI.injectEndpoints({
  endpoints: build => ({
    addSlider: build.mutation({
      query: values => {

        const modifiedFormData =  appendFormDataWithImgs(values);

        return{
        url: '/create-slider',
        method:'POST',
        body: modifiedFormData,
     };
    },
    invalidatesTags:['HomeSlidersList']
    }),
    editSlider: build.mutation({
      query: values => {

      const modifiedFormData =  appendFormDataWithImgs(values);

        return{
        url: `/update-slider/${values._id}`,
        method:'PATCH',
        body: modifiedFormData,
     };
    },
     invalidatesTags:['HomeSlidersList']
    }),
    getHomeSliders: build.query({
      query: params => {
        return{
        url: `/all-slider`  ,
        method:'GET',
        params
     };
    },
    providesTags:['HomeSlidersList']
    }),
    getSlider: build.query({
      query: id => {
        return{
        url: `/slider/${id}`,
        method:'GET',
     }; 
    },
    }),
  }),
});

export const {
useAddSliderMutation,
useEditSliderMutation,
useGetHomeSlidersQuery,
useGetSliderQuery
} = homeSlidersAPI;
