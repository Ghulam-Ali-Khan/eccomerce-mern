import { privateAPI } from './index';

export const usersAPI = privateAPI.injectEndpoints({
  endpoints: build => ({
    getUsers: build.query({
      query: params => {
        return{
        url: `/all-users`  ,
        method:'GET',
        params
     };
    },
    providesTags:['UsersList']
    }),
  }),
});

export const {
useGetUsersQuery,
} = usersAPI;
