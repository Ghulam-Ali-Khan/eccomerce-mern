import { appendFormDataWithImgs } from '@utilis/helpers';
import { privateAPI } from './index';

export const categoriessAPI = privateAPI.injectEndpoints({
  endpoints: build => ({
    addCategory: build.mutation({
      query: values => {

        const modifiedFormData =  appendFormDataWithImgs(values);

        return{
        url: '/create-category',
        method:'POST',
        body: modifiedFormData,
     };
    },
    invalidatesTags:['CategoriesList']
    }),
    editCategory: build.mutation({
      query: values => {

      const modifiedFormData =  appendFormDataWithImgs(values);

        return{
        url: `/update-category/${values._id}`,
        method:'PATCH',
        body: modifiedFormData,
     };
    },
     invalidatesTags:['CategoriesList']
    }),
    getCategoriresWithType: build.query({
      query: values => {
        return{
        url: `/type-categories/${values.type}`  ,
        method:'GET',
        params:{
          query: values?.query || null,
        }
     };
    }
    }),
    getCategorires: build.query({
      query: params => {
        return{
        url: `/all-categories`  ,
        method:'GET',
        params
     };
    },
    providesTags:['CategoriesList']
    }),
    getCategory: build.query({
      query: id => {
        return{
        url: `/categories/${id}`,
        method:'GET',
     }; 
    },
    }),
  }),
});

export const {
useAddCategoryMutation,
useEditCategoryMutation,
useGetCategoriresWithTypeQuery,
useGetCategoriresQuery,
useGetCategoryQuery
} = categoriessAPI;
