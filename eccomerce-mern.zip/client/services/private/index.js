import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { API_URL } from '@utilis/contants';
import { getTokenCookie } from '@utilis/authCookiesManage';


// eslint-disable-next-line import/prefer-default-export
export const privateAPI = createApi({
  reducerPath: 'privateAPI',
  tagTypes: [],
  baseQuery: fetchBaseQuery({
    baseUrl:  API_URL,
    prepareHeaders:async headers => {
      const token = await getTokenCookie();

      if (token) headers.set('Authorization', `Token ${token.value}`);

      return headers;
    },
  }),
  endpoints: () => ({}),
});
