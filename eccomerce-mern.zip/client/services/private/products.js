import { appendFormDataWithImgs } from '@utilis/helpers';
import { privateAPI } from './index';

export const productsAPI = privateAPI.injectEndpoints({
  endpoints: build => ({
    addProduct: build.mutation({
      query: values => {

      const modifiedFormData =  appendFormDataWithImgs(values);

        return{
        url: '/create-product',
        method:'POST',
        body: modifiedFormData,
     };
    },
     invalidatesTags:['ProductsList']
    }),
    editProduct: build.mutation({
      query: values => {

      const modifiedFormData =  appendFormDataWithImgs(values);

        return{
        url: `/update-product/${values._id}`,
        method:'PATCH',
        body: modifiedFormData,
     };
    },
     invalidatesTags:['ProductsList']
    }),
    getProducts: build.query({
      query: params => {
        return{
        url: '/all-product',
        method:'GET',
        params,
     };
     
    },
    providesTags:['ProductsList']
    }),
    getProduct: build.query({
      query: id => {
        return{
        url: `/products/${id}`,
        method:'GET',
     }; 
    },
    }),
  }),
});

export const {
useAddProductMutation,
useGetProductsQuery,
useGetProductQuery,
useEditProductMutation
} = productsAPI;
