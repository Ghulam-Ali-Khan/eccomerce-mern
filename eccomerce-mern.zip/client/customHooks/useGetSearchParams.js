"use client"

import { useSearchParams } from "next/navigation";

function useGetSearchParams() {
    const searchParams = useSearchParams();

   return  Object.fromEntries(searchParams);
 
}

export default useGetSearchParams;