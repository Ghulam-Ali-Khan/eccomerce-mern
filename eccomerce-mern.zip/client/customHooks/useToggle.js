"use client";

import { useCallback, useState } from 'react'

const useToggle = () => {

    const [isOpen, setOpen] = useState(false);

    const handleToggle =useCallback (()=>{
        setOpen(prev=>!prev);
    },[]);

  return [isOpen, handleToggle];
}

export default useToggle