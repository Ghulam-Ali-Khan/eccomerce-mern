import React, { useCallback } from "react";
import { FormHelperText, Typography, Grid, Box } from "@mui/material";
import BackupOutlinedIcon from "@mui/icons-material/BackupOutlined";
import PropTypes from "prop-types";
import { useField, useFormikContext } from "formik";
import styles from "@styles/modules/form.module.scss";
import Image from "next/image";
import { IMGS_URL } from "@utilis/contants";

function FormikDropzone({
  name,
  moduleType,
  label,
  onBlur,
  onChange,
  isRequired,
  disabled,
  isRow,
  classes,
  isSimple,
}) {
  const { values } = useFormikContext();
  const [field, meta, helpers] = useField(name || "");

  const { value, onBlur: onFieldBlur } = field;
  const { touched, error } = meta;
  const { setValue } = helpers;

  const styling = {
    border: "1px solid #ddd",
    borderRadius: "5px",
    cursor: "pointer",
    height: "150px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  };

  const handleChange = useCallback(e => {
    setValue(e.target.files);

    if (onChange) onChange(e);
  }, []);

  const handleBlur = useCallback(
    e => {
      onFieldBlur(e);

      if (onBlur) onBlur(e);
    },
    [values, onBlur]
  );

  // console.log('Dropzone field value ==> ', value);

  return (
    <Grid className={classes} spacing={1} container>
      <Grid
        item
        className="d-flex align-items-center"
        xl={isRow ? 3 : 12}
        lg={isRow ? 3 : 12}
        md={isRow ? 4 : 12}
        sm={12}
      >
        {label && (
          <Typography
            className={isRequired ? "required" : ""}
            variant="body2"
            sx={{ mb: "8px !important" }}
          >
            {label}
          </Typography>
        )}
      </Grid>
      <Grid
        sx={{ paddingTop: !isRow && "0px !important" }}
        item
        xl={isRow ? 9 : 12}
        lg={isRow ? 9 : 12}
        md={isRow ? 8 : 12}
        sm={12}
      >
        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
          {value &&
            Object?.entries(value)?.map(([imgKey, imgValue], index) => {
              const src = typeof imgValue === 'string' ? `${IMGS_URL}/${moduleType}/${imgValue}` : URL.createObjectURL(imgValue);

              return (
                <Image
                  key={`img-${index}-${imgKey}`}
                  src={src}
                  style={{ border: "1px solid #ddd", marginBottom: "5px" }}
                  width={60}
                  height={40}
                  alt=""
                />
              );
            })}
        </Box>
        <label
          htmlFor={name}
          style={{
            width: "100%",
            ...(isSimple ? {} : styling), // Conditionally apply additional styles if `isSimple` is false
          }}
          className={`${!isSimple ? styles.dropzoneHover : ""} ${classes}`}
        >
          {!isSimple && (
            <Typography variant="body1" sx={{ color: "#ddd" }}>
              Choose file <BackupOutlinedIcon />
            </Typography>
          )}
          <input
            style={{ display: !isSimple ? "none" : null }}
            name={name}
            id={name}
            type="file"
            disabled={disabled}
            onChange={handleChange}
            onBlur={handleBlur}
            multiple
          />
        </label>

        {touched && error && <FormHelperText error>{error}</FormHelperText>}
      </Grid>
    </Grid>
  );
}

FormikDropzone.propTypes = {
  name: PropTypes.string.isRequired,
  moduleType: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
  label: PropTypes.string,
  onBlur: PropTypes.func,
  onChange: PropTypes.func,
  isRequired: PropTypes.bool,
  classes: PropTypes.string,
  isRow: PropTypes.bool,
  isSimple: PropTypes.bool,
};

FormikDropzone.defaultProps = {
  disabled: false,
  onChange: () => {},
  onBlur: () => {},
  label: "",
  isRequired: false,
  classes: "",
  isRow: false,
  isSimple: false,
};

export default FormikDropzone;
