import React, { useCallback, useMemo } from 'react';
import { FormHelperText, Typography, Button, Grid } from '@mui/material';
import PropTypes from 'prop-types';
import Select from 'react-select';
import { useField } from 'formik';
import { useDebouncedCallback } from 'use-debounce';

// import { fieldStyles } from 'styles/containers/selectStyles';
// import useGetThemeColor from 'customHooks/useGetThemeColor';

const CUSTOM_BUTTON_VALUE = 'custom-menu-button';

function FormikSelect({
  name,
  options,
  disabled,
  onChange,
  onBlur,
  isGrouped,
  isClearable,
  onMenuCustomButtonClick,
  menuCustomButtonLabel,
  label,
  placeholder,
  menuPosition,
  menuPlacement,
  menuShouldBlockScroll,
  formatOptionLabel,
  isRequired,
  isStack,
  classes,
  isOpen,
  depenpencyArray,
  setSearchValue
}) {
  const [field, meta, helpers] = useField(name);

  const { value, onBlur: onFieldBlur } = field;
  const { touched, error } = meta;
  const { setValue } = helpers;

  // const primaryColor = useGetThemeColor();

  const handleChange = useCallback(selectedOption => {
    if (selectedOption?.value === CUSTOM_BUTTON_VALUE) return;

    const fieldValue = selectedOption?.value || null;
    setValue(fieldValue);

    if (onChange) onChange(fieldValue);
  }, [...depenpencyArray]);

  const handleBlur = useCallback(event => {
    onFieldBlur(event);

    if (onBlur) onBlur(name, event);
  }, [...depenpencyArray, value]);

  const handleInputChange = useDebouncedCallback(newValue => {
    setSearchValue(newValue);
    console.log('Search input value:', newValue);
  }, 500);

  const allOptions = useMemo(
    () => (isGrouped ? options.map(item => item.options).flatMap(item => item) : [...options]),
    [options]
  );
  const selectedOption = useMemo(
    () => allOptions.find(option => option?.value === value ?? ''),
    [allOptions, value]
  );

  const customButtonOption = {
    label: (
      <Button color="primary" onClick={onMenuCustomButtonClick}>
        {menuCustomButtonLabel}
      </Button>
    ),
    value: CUSTOM_BUTTON_VALUE,
  };

  const modifiedOptions = useMemo(
    () => [...options, ...(onMenuCustomButtonClick ? [customButtonOption] : [])],
    [options, onMenuCustomButtonClick]
  );

  return (
    <Grid
      className={classes}
      // sx={{ '& .react-select__option--is-selected, & .react-select__option--is-selected:hover': { backgroundColor: primaryColor } }}
      spacing={1}
      container
    >
      <Grid
                className="d-flex align-items-center p-0 m-0"
                sx={{ padding: '0px' }}
                item
                xl={isStack ? 12 : 3}
                lg={isStack ? 12 : 3}
                md={isStack ? 12 : 4}
                sm={12}
            >
        {label && (
          <Typography
            className={isRequired ? 'required' : ''}
            variant="body2"
            sx={{ mb: '2px !important' }}
          >
            {label}
          </Typography>
        )}
      </Grid>
      <Grid item xl={isStack ? 12 : 9} lg={isStack ? 12 : 9} md={isStack ? 12 : 8} sm={12} sx={{ paddingTop: '0px !important', paddingLeft: isStack ? '0px !important':null }}>
        <Select
          autoComplete="false"
          menuIsOpen={isOpen}
          options={modifiedOptions}
          name={name}
          onChange={handleChange}
          onBlur={handleBlur}
          value={selectedOption || null}
          classNamePrefix="react-select"
          isDisabled={disabled}
          disabled={disabled}
          isClearable={isClearable}
          // styles={fieldStyles}
          placeholder={placeholder}
          menuPosition={menuPosition}
          menuPlacement={menuPlacement}
          menuShouldBlockScroll={menuShouldBlockScroll}
          formatOptionLabel={formatOptionLabel}
          onInputChange={newValue=>{            
          if(setSearchValue) handleInputChange(newValue)
          }
          }
        />
        {touched && error && <FormHelperText error>{error}</FormHelperText>}
      </Grid>
    </Grid>
  );
}

FormikSelect.propTypes = {
  name: PropTypes.string.isRequired,
  options: PropTypes.arrayOf(PropTypes.object),
  label: PropTypes.string,
  placeholder: PropTypes.string,
  disabled: PropTypes.bool,
  menuPosition: PropTypes.string,
  menuPlacement: PropTypes.string,
  menuShouldBlockScroll: PropTypes.bool,
  isGrouped: PropTypes.bool,
  isClearable: PropTypes.bool,
  formatOptionLabel: PropTypes.func,
  onChange: PropTypes.func,
  onBlur: PropTypes.func,
  onMenuCustomButtonClick: PropTypes.func,
  menuCustomButtonLabel: PropTypes.string,
  isRequired: PropTypes.bool,
  isRow: PropTypes.bool,
  isOpen: PropTypes.bool,
  classes: PropTypes.string,
  depenpencyArray: PropTypes.array,
  setSearchValue: PropTypes.any,
};

FormikSelect.defaultProps = {
  isOpen: undefined,
  label: '',
  options: [],
  placeholder: '',
  disabled: false,
  menuPosition: 'absolute',
  menuPlacement: 'bottom',
  menuShouldBlockScroll: false,
  isGrouped: false,
  isClearable: false,
  formatOptionLabel: null,
  onChange: null,
  onBlur: null,
  onMenuCustomButtonClick: null,
  menuCustomButtonLabel: 'Add New',
  isRequired: false,
  isRow: false,
  classes: '',
  depenpencyArray: [],
  setSearchValue:null
};

export default FormikSelect;
