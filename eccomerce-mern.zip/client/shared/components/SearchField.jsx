"use client";

import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { Box, IconButton } from '@mui/material';
import { Search } from '@mui/icons-material';
import { Field } from 'formik';

import styles from '@styles/modules/form.module.scss';
import useGetSearchParams from '@customHooks/useGetSearchParams';
import FormikWrapper from '@components/common/form/FormikWrapper';
import { Suspense } from 'react';


function SearchField() {

    const { query } = useGetSearchParams();
    const searchParams = useSearchParams();
    const pathname = usePathname();
    const { replace } = useRouter();

    return (
        <Suspense fallback={<div>Loading...</div>}>
        <FormikWrapper
            initialValues={{ query: query || '' }}
            submitFunc={values => {
                const params = new URLSearchParams(searchParams);

                params.set('query', values.query);
                replace(`${pathname}?${params.toString()}`);
            }}
        >
            <Box className={styles.searchField}>
                <Field type="text" name="query" placeholder="Search" />
                <IconButton type='submit'>
                    <Search />
                </IconButton>
            </Box>
        </FormikWrapper>
        </Suspense>
    )
}

export default SearchField