import { Typography } from "@mui/material";
import { tableParameters } from "./contants";

export const utilityOptionsGenerator = data => (data?.length > 0) ? (data.map(option=> ({
    label: option.name,
    value: option._id,
}))):[];

export const renderedValueWithLabel = (value, label) => (
  value &&(<Typography variant="body1">
<span className="font-bold">{label} : </span> {value}
</Typography>)
);

export const appendFormDataWithImgs = values => {

    const formData =new FormData();

    Object.entries(values).forEach(([key, value]) => { 

        if(key ===  'card_imgs'|| key === 'banner_imgs' || key === 'slider_imgs')
          {
            Object.entries(value).forEach(([keyinner,img])=>{
              formData.append(key, img);
            })
          }else{

            formData.append(key, value);
         
          }
      });

      return formData;
}

export function getSearchParamsList(searchParams) {
  return Object.fromEntries(searchParams);
}

export const getPaginationData = query => {

  const limit = query?.limit || tableParameters.rowPerPage;
    const offset = query?.offset || '0';

  return { limit: +limit, offset: +offset, query };
};