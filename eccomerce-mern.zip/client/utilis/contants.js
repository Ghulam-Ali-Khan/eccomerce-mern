import WhiteLogo from '@public/assets/img/tech-sink-white-logo.png';
import Logo from '@public/assets/img/tech-sink-logo.png';

export const API_URL = 'http://localhost:5000/api';
export const IMGS_URL = 'http://localhost:5000/uploads';

export const fetchTypes = {
products: 'product',
blogs:'blog'
};

export const COMPANY_NAME = "Tech Sink";
export const DEFAULT_CURRENCY ="RS"
export const EMAIL_REGEX =
  /^(([^`~!$%^&*?/|}{#=<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

export const COMPANY_DETAILS = {
    name:'Tech Sink',
    logo: Logo,
    whiteLogo: WhiteLogo,
}


export const tableParameters = {
  rowPerPage:'20',
}